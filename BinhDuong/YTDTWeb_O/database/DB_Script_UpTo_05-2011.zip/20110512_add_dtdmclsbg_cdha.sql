alter table `db_ytdt_bd`.`dt_dm_cls_bang_gia` 
   add column `DTDMCLSBG_CDHA` varchar(2) NULL after `DMCLSBG_XN`;
   