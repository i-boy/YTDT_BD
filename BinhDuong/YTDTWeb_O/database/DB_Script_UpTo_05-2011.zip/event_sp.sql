/*Event RESET_MA_EOY*/
DROP EVENT IF EXISTS RESET_MA_EOY;
CREATE EVENT RESET_MA_EOY
 ON SCHEDULE EVERY 1 DAY
STARTS TIMESTAMP(CURRENT_DATE,'23:00:00')
 DO
  call SP_ResetMa_EOY();

/*Event RESET_MA_EOM*/
DROP EVENT IF EXISTS RESET_MA_EOM;
CREATE EVENT RESET_MA_EOM
 ON SCHEDULE EVERY 1 DAY
STARTS TIMESTAMP(CURRENT_DATE,'23:00:00')
 DO
  call SP_ResetMa_EOM();

/*SP_ResetMa_EOM*/
DELIMITER $$

DROP PROCEDURE IF EXISTS `SP_ResetMa_EOM` $$
CREATE PROCEDURE `SP_ResetMa_EOM` ()
BEGIN
  DECLARE cur_month INT;
  DECLARE next_month INT;
  SET cur_month = (SELECT MONTH(CURRENT_DATE()));
  SET next_month = (SELECT MONTH(DATE_ADD(CURRENT_DATE(),INTERVAL 1 DAY)));

  IF cur_month <> next_month THEN
    update yte_sequence set sequence_current_value = 0, sequence_current_next = 1 where sequence_id IN(6,7,8);
  END IF;
END $$

DELIMITER ;


/*SP_ResetMa_EOY*/
DELIMITER $$

DROP PROCEDURE IF EXISTS `SP_ResetMa_EOY` $$
CREATE PROCEDURE `SP_ResetMa_EOY` ()
BEGIN
  DECLARE cur_year INT;
  DECLARE next_year INT;
  SET cur_year = (SELECT YEAR(CURRENT_DATE()));
  SET next_year = (SELECT YEAR(DATE_ADD(CURRENT_DATE(),INTERVAL 1 DAY)));

  IF cur_year <> next_year THEN
    update yte_sequence set sequence_current_value = 0, sequence_current_next = 1 where sequence_id IN(1,2,3);
  END IF;
END $$

DELIMITER ;
