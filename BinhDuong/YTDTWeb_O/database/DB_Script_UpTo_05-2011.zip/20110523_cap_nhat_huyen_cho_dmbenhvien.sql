﻿update dm_benh_vien d set dmhuyen_maso = 374 where dmbenhvien_maso >= 10269 and dmbenhvien_maso <= 10289;
