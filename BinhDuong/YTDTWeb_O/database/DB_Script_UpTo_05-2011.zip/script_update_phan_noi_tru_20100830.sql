﻿ALTER TABLE `db_ytdt_bd`.`to_dieu_tri` DROP COLUMN `HSBACM_MA`,
 DROP FOREIGN KEY `FK_TO_DIEU_TRI_1`;

ALTER TABLE `db_ytdt_bd`.`to_dieu_tri` ADD COLUMN `HSBA_SOVAOVIEN` VARCHAR(17) DEFAULT NULL AFTER `BACSI`;

ALTER TABLE `db_ytdt_bd`.`to_dieu_tri` MODIFY COLUMN `HSBA_SOVAOVIEN` VARCHAR(17) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
 ADD CONSTRAINT `FK_TO_DIEU_TRI_1` FOREIGN KEY `FK_TO_DIEU_TRI_1` (`HSBA_SOVAOVIEN`)
    REFERENCES `hsba` (`HSBA_SOVAOVIEN`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION;

ALTER TABLE `db_ytdt_bd`.`phieu_cham_soc`
 DROP FOREIGN KEY `FK_PHIEU_CHAM_SOC_1`;

ALTER TABLE `db_ytdt_bd`.`phieu_cham_soc` DROP COLUMN `HSBACM_MA`,
 ADD COLUMN `HSBA_SOVAOVIEN` VARCHAR(17) CHARACTER SET utf8 COLLATE utf8_unicode_ci AFTER `BACSI`
, DROP INDEX `FK_PHIEU_CHAM_SOC_1`,
 ADD CONSTRAINT `FK_PHIEU_CHAM_SOC_1` FOREIGN KEY `FK_PHIEU_CHAM_SOC_1` (`HSBA_SOVAOVIEN`)
    REFERENCES `hsba` (`HSBA_SOVAOVIEN`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION;

CREATE TABLE `db_ytdt_bd`.`phieu_theo_doi_truyen_dich` (
  `PTDTD_MASO` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  `HSBA_SOVAOVIEN` VARCHAR(17) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Khoa ngoai tham chieu den bang :  hsba',
  `DMTHUOC_MASO` INTEGER UNSIGNED COMMENT 'Khoa ngoai tham chieu den bang : dm_thuoc',
  `PTDTD_TOCDO` MEDIUMINT UNSIGNED COMMENT 'Toc do giot/phut',
  `PTDTD_BATDAU` DATETIME COMMENT 'Ngay gio bat dau truyen dich',
  `PTDTD_KETTHUC` DATETIME COMMENT 'Ngay gio ket thuc truyen dich',
  `BACSI_MASO` INTEGER UNSIGNED COMMENT 'Bac si chi dinh, khoa ngoai tham chieu den bang : dt_dm_nhan_vien',
  `YTA_MASO` INTEGER UNSIGNED COMMENT 'Yta, dieu duong thuc hien, khoa ngoai tham chieu den bang : dt_dm_nhan_vien',
  PRIMARY KEY (`PTDTD_MASO`),
  CONSTRAINT `FK_phieu_theo_doi_truyen_dich_1` FOREIGN KEY `FK_phieu_theo_doi_truyen_dich_1` (`HSBA_SOVAOVIEN`)
    REFERENCES `hsba` (`HSBA_SOVAOVIEN`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_phieu_theo_doi_truyen_dich_2` FOREIGN KEY `FK_phieu_theo_doi_truyen_dich_2` (`DMTHUOC_MASO`)
    REFERENCES `dm_thuoc` (`DMTHUOC_MASO`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_phieu_theo_doi_truyen_dich_3` FOREIGN KEY `FK_phieu_theo_doi_truyen_dich_3` (`BACSI_MASO`)
    REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_phieu_theo_doi_truyen_dich_4` FOREIGN KEY `FK_phieu_theo_doi_truyen_dich_4` (`YTA_MASO`)
    REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION
)
ENGINE = InnoDB;

ALTER TABLE `db_ytdt_bd`.`phieu_theo_doi_truyen_dich` ADD COLUMN `PTDTD_SOLUONG` SMALLINT UNSIGNED COMMENT 'So luong' AFTER `YTA_MASO`;
ALTER TABLE `db_ytdt_bd`.`phieu_theo_doi_truyen_dich` ADD COLUMN `TONKHO_MA` INTEGER UNSIGNED COMMENT 'Khoa ngoai tham chieu de bang :  ton_kho' AFTER `PTDTD_SOLUONG`;
ALTER TABLE `db_ytdt_bd`.`phieu_theo_doi_truyen_dich` MODIFY COLUMN `TONKHO_MA` INTEGER DEFAULT NULL COMMENT 'Khoa ngoai tham chieu de bang :  ton_kho',
 ADD CONSTRAINT `FK_phieu_theo_doi_truyen_dich_5` FOREIGN KEY `FK_phieu_theo_doi_truyen_dich_5` (`TONKHO_MA`)
    REFERENCES `ton_kho` (`TONKHO_MA`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION;
