﻿ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_mat`
 DROP FOREIGN KEY `FK_HSBA_CHI_TIET_MAT_1`;

ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_mat` ADD CONSTRAINT `FK_HSBA_CHI_TIET_MAT_1` FOREIGN KEY `FK_HSBA_CHI_TIET_MAT_1` (`HSBACM_MA`)
    REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;

	
ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_naophathai_ct`
 DROP FOREIGN KEY `FK_CT_BENH_AN_NAOPHATHAI_3`;

ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_naophathai_ct` ADD CONSTRAINT `FK_CT_BENH_AN_NAOPHATHAI_3` FOREIGN KEY `FK_CT_BENH_AN_NAOPHATHAI_3` (`HSBACTNAOPHATHAI_MA`)
    REFERENCES `hsba_chi_tiet_naophathai` (`HSBACTNAOPHATHAI_MA`)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;

	
ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_naophathai`
 DROP FOREIGN KEY `FK_HSBA_CHI_TIET_NAOPHATHAI_1`;

ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_naophathai` ADD CONSTRAINT `FK_HSBA_CHI_TIET_NAOPHATHAI_1` FOREIGN KEY `FK_HSBA_CHI_TIET_NAOPHATHAI_1` (`HSBACM_MA`)
    REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;

	
ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_ngoaitru_yhct`
 DROP FOREIGN KEY `FK_HSBA_CHI_TIET_NGOAITRU_YHCT_1`;

ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_ngoaitru_yhct` ADD CONSTRAINT `FK_HSBA_CHI_TIET_NGOAITRU_YHCT_1` FOREIGN KEY `FK_HSBA_CHI_TIET_NGOAITRU_YHCT_1` (`HSBACM_MA`)
    REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;

	
ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_nhikhoa`
 DROP FOREIGN KEY `FK_HSBA_CHI_TIET_NHIKHOA_1`;

ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_nhikhoa` ADD CONSTRAINT `FK_HSBA_CHI_TIET_NHIKHOA_1` FOREIGN KEY `FK_HSBA_CHI_TIET_NHIKHOA_1` (`HSBACM_MA`)
    REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;

	
ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_noi`
 DROP FOREIGN KEY `FK_HSBA_CHI_TIET_NOI_1`;

ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_noi` ADD CONSTRAINT `FK_HSBA_CHI_TIET_NOI_1` FOREIGN KEY `FK_HSBA_CHI_TIET_NOI_1` (`HSBACM_MA`)
    REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;


ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_noitru_yhct`
 DROP FOREIGN KEY `FK_HSBA_CHI_TIET_NOITRU_YHCT_1`;

ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_noitru_yhct` ADD CONSTRAINT `FK_HSBA_CHI_TIET_NOITRU_YHCT_1` FOREIGN KEY `FK_HSBA_CHI_TIET_NOITRU_YHCT_1` (`HSBACM_MA`)
    REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;

	
ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_phukhoa`
 DROP FOREIGN KEY `FK_HSBA_CHI_TIET_PHUKHOA_1`;

ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_phukhoa` ADD CONSTRAINT `FK_HSBA_CHI_TIET_PHUKHOA_1` FOREIGN KEY `FK_HSBA_CHI_TIET_PHUKHOA_1` (`HSBACM_MA`)
    REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;

	
ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_rhm`
 DROP FOREIGN KEY `FK_hsba_chi_tiet_rhm_1`;

ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_rhm` ADD CONSTRAINT `FK_hsba_chi_tiet_rhm_1` FOREIGN KEY `FK_hsba_chi_tiet_rhm_1` (`HSBACM_MA`)
    REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;

	
ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_sankhoa`
 DROP FOREIGN KEY `FK_HSBA_CHI_TIET_SANKHOA_1`;

ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_sankhoa` ADD CONSTRAINT `FK_HSBA_CHI_TIET_SANKHOA_1` FOREIGN KEY `FK_HSBA_CHI_TIET_SANKHOA_1` (`HSBACM_MA`)
    REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;

	
ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_sosinh`
 DROP FOREIGN KEY `FK_HSBA_CHI_TIET_SOSINH_1`;

ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_sosinh` ADD CONSTRAINT `FK_HSBA_CHI_TIET_SOSINH_1` FOREIGN KEY `FK_HSBA_CHI_TIET_SOSINH_1` (`HSBACM_MA`)
    REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;

	
ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_tmh`
 DROP FOREIGN KEY `FK_hsba_chi_tiet_tmh_1`;

ALTER TABLE `db_ytdt_bd`.`hsba_chi_tiet_tmh` ADD CONSTRAINT `FK_hsba_chi_tiet_tmh_1` FOREIGN KEY `FK_hsba_chi_tiet_tmh_1` (`HSBACM_MA`)
    REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;

