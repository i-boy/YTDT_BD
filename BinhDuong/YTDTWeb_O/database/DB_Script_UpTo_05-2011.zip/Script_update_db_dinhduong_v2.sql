﻿ALTER TABLE `db_ytdt_bd`.`phieu_bao_an`
 DROP FOREIGN KEY `FK_PHIEUBAOAN_KHOA`;

ALTER TABLE `db_ytdt_bd`.`phieu_bao_an`
 DROP FOREIGN KEY `FK_PHIEUBAOAN_NHANVIEN_DUYET`;

ALTER TABLE `db_ytdt_bd`.`phieu_bao_an`
 DROP FOREIGN KEY `FK_PHIEUBAOAN_NHANVIEN_NHAP`;

ALTER TABLE `db_ytdt_bd`.`phieu_bao_an` MODIFY COLUMN `PHIEUBAOAN_NGAYGIO` DATE DEFAULT NULL,
 DROP COLUMN `HSBA_SOVAOVIEN`,
 DROP COLUMN `PHONG_MASO`,
 DROP COLUMN `MUCAN_MASO`,
 DROP COLUMN `LOAIAN_MASO`,
 DROP COLUMN `CHEDOAN_MASO`,
 DROP COLUMN `PHIEUBAOAN_NGAYGIOCN`,
 DROP COLUMN `PHIEUBAOAN_CHON`,
 DROP COLUMN `DOITUONG_MASO`,
 DROP COLUMN `PHIEUBAOAN_GIOAN`,
 MODIFY COLUMN `PHIEUBAOAN_TRANGTHAIDUYET` TINYINT(1) DEFAULT 0
, DROP INDEX `FK_PHIEU_BAO_AN_DTDMMA`
, DROP INDEX `FK_PHIEU_BAO_AN_DTDMLA`
, DROP INDEX `FK_PHIEU_BAO_AN_DTDMCDA`
, DROP INDEX `FK_PHIEUBAOAN_DOITUONG`
, DROP INDEX `FK_PHIEUBAOAN_HSBA`
, DROP INDEX `FK_PHIEUBAOAN_PHONG`,
 DROP FOREIGN KEY `FK_PHIEUBAOAN_DOITUONG`,
 DROP FOREIGN KEY `FK_PHIEUBAOAN_HSBA`,
 ADD CONSTRAINT `FK_PHIEUBAOAN_KHOA` FOREIGN KEY `FK_PHIEUBAOAN_KHOA` (`KHOA_MASO`)
    REFERENCES `dm_khoa` (`DMKHOA_MASO`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
 ADD CONSTRAINT `FK_PHIEUBAOAN_NHANVIEN_DUYET` FOREIGN KEY `FK_PHIEUBAOAN_NHANVIEN_DUYET` (`NHANVIEN_DUYET_MASO`)
    REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
 ADD CONSTRAINT `FK_PHIEUBAOAN_NHANVIEN_NHAP` FOREIGN KEY `FK_PHIEUBAOAN_NHANVIEN_NHAP` (`NHANVIEN_NHAP_MASO`)
    REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
 DROP FOREIGN KEY `FK_PHIEUBAOAN_PHONG`,
 DROP FOREIGN KEY `FK_PHIEU_BAO_AN_DTDMCDA`,
 DROP FOREIGN KEY `FK_PHIEU_BAO_AN_DTDMLA`,
 DROP FOREIGN KEY `FK_PHIEU_BAO_AN_DTDMMA`;

ALTER TABLE `db_ytdt_bd`.`phieu_bao_an` MODIFY COLUMN `PHIEUBAOAN_MA` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
 CHANGE COLUMN `PHIEUBAOAN_NGAYGIO` `PHIEUBAOAN_NGAYAN` DATE DEFAULT NULL;

ALTER TABLE `db_ytdt_bd`.`dt_dm_loai_an` MODIFY COLUMN `DTDMLA_TEN` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
 MODIFY COLUMN `DTDMLA_CHON` TINYINT(1) UNSIGNED DEFAULT 1;

CREATE TABLE  `db_ytdt_bd`.`dt_dm_loai_an_2` (
  `DTDMLA2_MASO` int(10) unsigned NOT NULL auto_increment,
  `DTDMLA2_MA` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `DTDMLA2_TEN` varchar(100) character set utf8 collate utf8_unicode_ci default NULL,
  `DTDMLA2_NGAYGIOCN` double default NULL,
  `DTDMLA2_CHON` tinyint(1) unsigned default '1',
  `DTDMLA_MASO` int(10) unsigned default NULL,
  PRIMARY KEY  (`DTDMLA2_MASO`),
  UNIQUE KEY `DTDMLA2_MA` (`DTDMLA2_MA`),
  KEY `FK_dt_dm_loai_an_2_1` (`DTDMLA_MASO`),
  CONSTRAINT `FK_dt_dm_loai_an_2_1` FOREIGN KEY (`DTDMLA_MASO`) REFERENCES `dt_dm_loai_an` (`DTDMLA_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

ALTER TABLE `db_ytdt_bd`.`dt_dm_muc_an` MODIFY COLUMN `DTDMMA_MA` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
 MODIFY COLUMN `DTDMMA_TEN` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
 MODIFY COLUMN `DTDMMA_NGAYGIOCN` DOUBLE UNSIGNED DEFAULT NULL,
 DROP COLUMN `DTDMMA_GIA`,
 MODIFY COLUMN `DTDMMA_CHON` TINYINT(1) UNSIGNED DEFAULT 1;

ALTER TABLE `db_ytdt_bd`.`dt_dm_che_do_an` MODIFY COLUMN `DTDMCDA_MA` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
 MODIFY COLUMN `DTDMCDA_TEN` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
 MODIFY COLUMN `DTDMCDA_NGAYGIOCN` DOUBLE UNSIGNED DEFAULT NULL,
 MODIFY COLUMN `DTDMCDA_CHON` TINYINT(1) UNSIGNED DEFAULT NULL;

CREATE TABLE  `db_ytdt_bd`.`dt_dm_doi_tuong_an` (
  `DTDMDTA_MASO` int(10) unsigned NOT NULL auto_increment,
  `DTDMDTA_MA` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `DTDMDTA_TEN` varchar(100) character set utf8 collate utf8_unicode_ci default NULL,
  `DTDMDTA_NGAYGIOCN` double default NULL,
  `DTDMDTA_CHON` tinyint(1) unsigned default '1',
  PRIMARY KEY  (`DTDMDTA_MASO`),
  UNIQUE KEY `DTDMDTA_MA` (`DTDMDTA_MA`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

CREATE TABLE  `db_ytdt_bd`.`dt_dm_dong_them` (
  `DTDMDT_MASO` int(10) unsigned NOT NULL auto_increment,
  `DTDMDT_MA` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `DTDMDT_TEN` varchar(100) character set utf8 collate utf8_unicode_ci default NULL,
  `DTDMDT_NGAYGIOCN` double default NULL,
  `DTDMDT_CHON` tinyint(1) unsigned default '1',
  PRIMARY KEY  (`DTDMDT_MASO`),
  UNIQUE KEY `DTDMDT_MA` (`DTDMDT_MA`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


CREATE TABLE  `db_ytdt_bd`.`benh_nhan_phieu_bao_an` (
  `BNPBA_MASO` int(10) unsigned NOT NULL auto_increment,
  `PHIEUBAOAN_MASO` int(10) unsigned default NULL,
  `HSBA_SOVAOVIEN` varchar(17) character set utf8 collate utf8_unicode_ci default NULL,
  `DTDMLA_MASO` int(10) unsigned default NULL,
  `DTDMLA2_MASO` int(10) unsigned default NULL,
  `DTDMDTA_MASO` int(10) unsigned default NULL,
  `DTDMMA_MASO` int(10) unsigned default NULL,
  `DTDMDT_MASO` int(10) unsigned default NULL,
  `BNPBN_PHUTROI` tinyint(3) unsigned default NULL COMMENT 'Luu gia tri 0 hoac 1 (1 : phu troi; 0 : khong phai phu troi)',
  PRIMARY KEY  (`BNPBA_MASO`),
  KEY `FK_benh_nhan_phieu_bao_an_1` (`PHIEUBAOAN_MASO`),
  KEY `FK_benh_nhan_phieu_bao_an_2` (`HSBA_SOVAOVIEN`),
  KEY `FK_benh_nhan_phieu_bao_an_3` (`DTDMLA_MASO`),
  KEY `FK_benh_nhan_phieu_bao_an_4` (`DTDMLA2_MASO`),
  KEY `FK_benh_nhan_phieu_bao_an_5` (`DTDMDTA_MASO`),
  KEY `FK_benh_nhan_phieu_bao_an_6` (`DTDMMA_MASO`),
  KEY `FK_benh_nhan_phieu_bao_an_7` (`DTDMDT_MASO`),
  CONSTRAINT `FK_benh_nhan_phieu_bao_an_1` FOREIGN KEY (`PHIEUBAOAN_MASO`) REFERENCES `phieu_bao_an` (`PHIEUBAOAN_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_benh_nhan_phieu_bao_an_2` FOREIGN KEY (`HSBA_SOVAOVIEN`) REFERENCES `hsba` (`HSBA_SOVAOVIEN`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_benh_nhan_phieu_bao_an_3` FOREIGN KEY (`DTDMLA_MASO`) REFERENCES `dt_dm_loai_an` (`DTDMLA_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_benh_nhan_phieu_bao_an_4` FOREIGN KEY (`DTDMLA2_MASO`) REFERENCES `dt_dm_loai_an_2` (`DTDMLA2_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_benh_nhan_phieu_bao_an_5` FOREIGN KEY (`DTDMDTA_MASO`) REFERENCES `dt_dm_doi_tuong_an` (`DTDMDTA_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_benh_nhan_phieu_bao_an_6` FOREIGN KEY (`DTDMMA_MASO`) REFERENCES `dt_dm_muc_an` (`DTDMMA_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_benh_nhan_phieu_bao_an_7` FOREIGN KEY (`DTDMDT_MASO`) REFERENCES `dt_dm_dong_them` (`DTDMDT_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Luu thong tin benh nhan theo phieu bao an';

CREATE TABLE  `db_ytdt_bd`.`benh_nhan_che_do_an` (
  `BNCDA_MASO` int(10) unsigned NOT NULL auto_increment,
  `BNPBA_MASO` int(10) unsigned default NULL,
  `DTDMCDA_MASO` int(10) unsigned default NULL,
  PRIMARY KEY  (`BNCDA_MASO`),
  KEY `FK_benh_nhan_che_do_an_1` (`BNPBA_MASO`),
  KEY `FK_benh_nhan_che_do_an_2` (`DTDMCDA_MASO`),
  CONSTRAINT `FK_benh_nhan_che_do_an_1` FOREIGN KEY (`BNPBA_MASO`) REFERENCES `benh_nhan_phieu_bao_an` (`BNPBA_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_benh_nhan_che_do_an_2` FOREIGN KEY (`DTDMCDA_MASO`) REFERENCES `dt_dm_che_do_an` (`DTDMCDA_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE  `db_ytdt_bd`.`dt_dm_gio_an` (
  `DTDMGA_MASO` int(10) unsigned NOT NULL auto_increment,
  `DTDMGA_MA` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `DTDMGA_TEN` varchar(100) character set utf8 collate utf8_unicode_ci default NULL,
  `DTDMGA_NGAYGIOCN` double default NULL,
  `DTDMGA_CHON` tinyint(1) unsigned default '1',
  PRIMARY KEY  (`DTDMGA_MASO`),
  UNIQUE KEY `DTDMGA_MA` (`DTDMGA_MA`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

CREATE TABLE  `db_ytdt_bd`.`benh_nhan_gio_an` (
  `BNGA_MASO` int(10) unsigned NOT NULL auto_increment,
  `BNPBA_MASO` int(10) unsigned default NULL,
  `DTDMGA_MASO` int(10) unsigned default NULL,
  PRIMARY KEY  (`BNGA_MASO`),
  KEY `FK_benh_nhan_gio_an_1` (`BNPBA_MASO`),
  KEY `FK_benh_nhan_gio_an_2` (`DTDMGA_MASO`),
  CONSTRAINT `FK_benh_nhan_gio_an_1` FOREIGN KEY (`BNPBA_MASO`) REFERENCES `benh_nhan_phieu_bao_an` (`BNPBA_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_benh_nhan_gio_an_2` FOREIGN KEY (`DTDMGA_MASO`) REFERENCES `dt_dm_gio_an` (`DTDMGA_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE  `db_ytdt_bd`.`dt_dm_loai_sua_duong_nhi` (
  `DTDMLSDN_MASO` int(10) unsigned NOT NULL auto_increment,
  `DTDMLSDN_MA` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `DTDMLSDN_TEN` varchar(100) character set utf8 collate utf8_unicode_ci default NULL,
  `DTDMLSDN_NGAYGIOCN` double default NULL,
  `DTDMLSDN_CHON` tinyint(1) unsigned default '1',
  PRIMARY KEY  (`DTDMLSDN_MASO`),
  UNIQUE KEY `DTDMLSDN_MA` (`DTDMLSDN_MA`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

ALTER TABLE `db_ytdt_bd`.`benh_nhan_phieu_bao_an` CHANGE COLUMN `BNPBN_PHUTROI` `BNPBA_PHUTROI` TINYINT(3) UNSIGNED DEFAULT NULL COMMENT 'Luu gia tri 0 hoac 1 (1 : phu troi; 0 : khong phai phu troi)',
 ADD COLUMN `DTDMLSDN_MASO` INTEGER UNSIGNED AFTER `BNPBA_PHUTROI`,
 ADD COLUMN `BNPBA_SOLUONG` MEDIUMINT UNSIGNED COMMENT 'So luong tinh banh ml (chi danh cho truong hop Loai an la Sua duong nhi)' AFTER `DTDMLSDN_MASO`;

ALTER TABLE `db_ytdt_bd`.`benh_nhan_phieu_bao_an` ADD COLUMN `BNPBA_DANGSUA` TINYINT UNSIGNED COMMENT 'Luu gia tri 0 hoac 1, (0 : Sua pha, 1 : Sua hop)' AFTER `BNPBA_SOLUONG`;

CREATE TABLE  `db_ytdt_bd`.`dt_dm_loai_thuc_pham` (
  `DTDMLTP_MASO` int(10) unsigned NOT NULL auto_increment,
  `DTDMLTP_MA` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `DTDMLTP_TEN` varchar(100) character set utf8 collate utf8_unicode_ci default NULL,
  `DTDMLTP_NGAYGIOCN` double default NULL,
  `DTDMLTP_CHON` tinyint(1) unsigned default '1',
  `DMDONVITINH_MASO` int(10) unsigned default NULL,
  PRIMARY KEY  (`DTDMLTP_MASO`),
  UNIQUE KEY `DTDMLTP_MA` (`DTDMLTP_MA`),
  KEY `FK_dt_dm_loai_thuc_pham_1` (`DMDONVITINH_MASO`),
  CONSTRAINT `FK_dt_dm_loai_thuc_pham_1` FOREIGN KEY (`DMDONVITINH_MASO`) REFERENCES `dm_don_vi_tinh` (`DMDONVITINH_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


DROP TABLE IF EXISTS `db_ytdt_bd`.`du_tru_thuc_pham`;
CREATE TABLE  `db_ytdt_bd`.`du_tru_thuc_pham` (
  `DTTP_MASO` int(10) unsigned NOT NULL auto_increment,
  `DTDMLTP_MASO` int(10) unsigned default NULL,
  `DTTP_SLTHUCDAT` float unsigned default NULL,
  `DTTP_SLTHUCGIAO` float unsigned default NULL,
  `DTTP_GHICHU` varchar(255) default NULL,
  `DTTP_NGAYDUTRU` date default NULL,
  PRIMARY KEY  (`DTTP_MASO`),
  KEY `FK_du_tru_thuc_pham_1` (`DTDMLTP_MASO`),
  CONSTRAINT `FK_du_tru_thuc_pham_1` FOREIGN KEY (`DTDMLTP_MASO`) REFERENCES `dt_dm_loai_thuc_pham` (`DTDMLTP_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `dt_dm_loai_an` (`DTDMLA_MASO`,`DTDMLA_MA`,`DTDMLA_TEN`,`DTDMLA_NGAYGIOCN`,`DTDMLA_CHON`) VALUES
 (1,'KHAUPHAN','Khẩu phần',1,1),
 (2,'SPDD','Sản phẩm dinh dưỡng',1,1),
 (3,'SDN','Sữa dưỡng nhi',1,1);

INSERT INTO `dt_dm_loai_an_2` (`DTDMLA2_MASO`,`DTDMLA2_MA`,`DTDMLA2_TEN`,`DTDMLA2_NGAYGIOCN`,`DTDMLA2_CHON`,`DTDMLA_MASO`) VALUES
 (1,'SONDE','Ăn qua sonde',1,1,1),
 (2,'CHAO','Cháo',1,1,1),
 (3,'COM','Cơm',1,1,1),
 (4,'SPDD_DUONG','Đường',1,1,2),
 (5,'SPDD_SUADAC','Sửa đặc',1,1,2),
 (6,'SDN_NT','Sữa non tháng',1,1,3),
 (7,'SDN_STEP1','Sữa Step 1',1,1,3);

INSERT INTO `dt_dm_muc_an` (`DTDMMA_MASO`,`DTDMMA_MA`,`DTDMMA_TEN`,`DTDMMA_NGAYGIOCN`,`DTDMMA_CHON`) VALUES
 (1,'30000','30.000',1,1),
 (2,'60000','60.000',1,1);

INSERT INTO `dt_dm_che_do_an` (`DTDMCDA_MASO`,`DTDMCDA_MA`,`DTDMCDA_TEN`,`DTDMCDA_NGAYGIOCN`,`DTDMCDA_CHON`) VALUES
 (1,'LAT','Lạt',1,1),
 (2,'DD','ĐĐ',1,1),
 (3,'STM','STM',1,1),
 (4,'THUONG','Thường',1,1),
 (5,'CMO','C.mỡ',1,1);

INSERT INTO `dt_dm_doi_tuong_an` (`DTDMDTA_MASO`,`DTDMDTA_MA`,`DTDMDTA_TEN`,`DTDMDTA_NGAYGIOCN`,`DTDMDTA_CHON`) VALUES
 (1,'BVD','BV duyệt (miễn phí)',1,1),
 (2,'NN','Nhà nuôi (miễn phí)',1,1),
 (3,'TC','Trung cao (miễn phí)',1,1),
 (4,'DT','Đóng tiền',1,1);

INSERT INTO `dt_dm_dong_them` (`DTDMDT_MASO`,`DTDMDT_MA`,`DTDMDT_TEN`,`DTDMDT_NGAYGIOCN`,`DTDMDT_CHON`) VALUES
 (1,'10000','10.000',1,1),
 (2,'20000','20.000',1,1),
 (3,'30000','30.000',1,1),
 (4,'40000','40.000',1,1);

INSERT INTO `dt_dm_gio_an` (`DTDMGA_MASO`,`DTDMGA_MA`,`DTDMGA_TEN`,`DTDMGA_NGAYGIOCN`,`DTDMGA_CHON`) VALUES
 (1,'6','6',1,1),
 (2,'11','11',1,1),
 (3,'16','16',1,1),
 (4,'20','20',1,1);

CREATE TABLE  `db_ytdt_bd`.`dt_dm_nha_sx_spdd` (
  `DTDMNSX_MASO` int(10) unsigned NOT NULL auto_increment,
  `DTDMNSX_MA` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `DTDMNSX_TEN` varchar(100) character set utf8 collate utf8_unicode_ci default NULL,
  `DTDMNSX_NGAYGIOCN` double default NULL,
  `DTDMNSX_CHON` tinyint(1) unsigned default '1',
  PRIMARY KEY  (`DTDMNSX_MASO`),
  UNIQUE KEY `DTDMNSX_MA` (`DTDMNSX_MA`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


CREATE TABLE  `db_ytdt_bd`.`nhap_kho_dinh_duong` (
  `NKDD_MASO` int(10) unsigned NOT NULL auto_increment,
  `NKDD_NGAYNHAP` date default NULL,
  `DTDMLA_MASO` int(10) unsigned default NULL,
  `DTDMLA2_MASO` int(10) unsigned default NULL,
  `DTDMNSX_MASO` int(10) unsigned default NULL,
  `NKDD_SOLUONG` float default NULL,
  `NKDD_DONVITINH` tinyint(3) unsigned default NULL COMMENT '0 : hop,  1 : kg',
  `NKDD_NGUOINHAP` varchar(100) default NULL,
  PRIMARY KEY  (`NKDD_MASO`),
  KEY `FK_nhap_kho_dinh_duong_1` (`DTDMLA_MASO`),
  KEY `FK_nhap_kho_dinh_duong_2` (`DTDMLA2_MASO`),
  KEY `FK_nhap_kho_dinh_duong_3` (`DTDMNSX_MASO`),
  CONSTRAINT `FK_nhap_kho_dinh_duong_1` FOREIGN KEY (`DTDMLA_MASO`) REFERENCES `dt_dm_loai_an` (`DTDMLA_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_nhap_kho_dinh_duong_2` FOREIGN KEY (`DTDMLA2_MASO`) REFERENCES `dt_dm_loai_an_2` (`DTDMLA2_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_nhap_kho_dinh_duong_3` FOREIGN KEY (`DTDMNSX_MASO`) REFERENCES `dt_dm_nha_sx_spdd` (`DTDMNSX_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE  `db_ytdt_bd`.`xuat_kho_dinh_duong` (
  `XKDD_MASO` int(10) unsigned NOT NULL auto_increment,
  `XKDD_NGAYXUAT` date default NULL,
  `DTDMLA_MASO` int(10) unsigned default NULL,
  `DTDMLA2_MASO` int(10) unsigned default NULL,
  `DTDMNSX_MASO` int(10) unsigned default NULL,
  `XKDD_SOLUONG` float default NULL,
  `XKDD_DONVITINH` tinyint(3) unsigned default NULL COMMENT '0 : hop,  1 : kg',
  `XKDD_NGUOIXUAT` varchar(100) default NULL,
  PRIMARY KEY  (`XKDD_MASO`),
  KEY `FK_xuat_kho_dinh_duong_1` (`DTDMLA_MASO`),
  KEY `FK_xuat_kho_dinh_duong_2` (`DTDMLA2_MASO`),
  KEY `FK_xuat_kho_dinh_duong_3` (`DTDMNSX_MASO`),
  CONSTRAINT `FK_xuat_kho_dinh_duong_1` FOREIGN KEY (`DTDMLA_MASO`) REFERENCES `dt_dm_loai_an` (`DTDMLA_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_xuat_kho_dinh_duong_2` FOREIGN KEY (`DTDMLA2_MASO`) REFERENCES `dt_dm_loai_an_2` (`DTDMLA2_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_xaut_kho_dinh_duong_3` FOREIGN KEY (`DTDMNSX_MASO`) REFERENCES `dt_dm_nha_sx_spdd` (`DTDMNSX_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `db_ytdt_bd`.`xuat_kho_dinh_duong` ADD COLUMN `DMKHOA_MASO` INTEGER UNSIGNED AFTER `XKDD_NGUOIXUAT`,
 ADD CONSTRAINT `FK_xuat_kho_dinh_duong_4` FOREIGN KEY `FK_xuat_kho_dinh_duong_4` (`DMKHOA_MASO`)
    REFERENCES `dm_khoa` (`DMKHOA_MASO`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION;


CREATE TABLE  `db_ytdt_bd`.`ton_kho_dinh_duong` (
  `TKDD_MASO` int(10) unsigned NOT NULL auto_increment,
  `TKDD_NGAYTON` date default NULL,
  `DTDMLA_MASO` int(10) unsigned default NULL,
  `DTDMLA2_MASO` int(10) unsigned default NULL,
  `DTDMNSX_MASO` int(10) unsigned default NULL,
  `TKDD_SOLUONG` float default NULL,
  `TKDD_DONVITINH` tinyint(3) unsigned default NULL COMMENT '0 : hop,  1 : kg',
  PRIMARY KEY  (`TKDD_MASO`),
  KEY `FK_ton_kho_dinh_duong_1` (`DTDMLA_MASO`),
  KEY `FK_ton_kho_dinh_duong_2` (`DTDMLA2_MASO`),
  KEY `FK_ton_kho_dinh_duong_3` (`DTDMNSX_MASO`),
  CONSTRAINT `FK_ton_kho_dinh_duong_1` FOREIGN KEY (`DTDMLA_MASO`) REFERENCES `dt_dm_loai_an` (`DTDMLA_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_ton_kho_dinh_duong_2` FOREIGN KEY (`DTDMLA2_MASO`) REFERENCES `dt_dm_loai_an_2` (`DTDMLA2_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_ton_kho_dinh_duong_3` FOREIGN KEY (`DTDMNSX_MASO`) REFERENCES `dt_dm_nha_sx_spdd` (`DTDMNSX_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;