﻿CREATE OR REPLACE VIEW  v_union_an_cls
AS
SELECT v.HSBA_SOVAOVIEN,
       null AS LOAICLS_MASO,
       ' Ăn' AS LOAICLS_TEN,
       -1 AS CLSBG_MASO,
       ' ' AS CLSBG_TEN,
       v.LANAN AS SOLAN,
       -- (CAST(v.MUCAN AS DECIMAL) * v.LANAN) AS THANHTIEN,
       -- Muc an dong them tinh theo ngay, khong nhan voi so lan an
       CAST(v.MUCAN AS DECIMAL) AS THANHTIEN,
       v.NGAYAN AS CLSMO_NGAY
FROM db_ytdt_bd.v_thongtinan v
UNION ALL
SELECT * FROM db_ytdt_bd.v_thongtincls ;