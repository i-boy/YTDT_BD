alter table `db_ytdt_bd`.`kiem_ke_kho` 
   add column `TONKHO_MA` int(11) NULL after `KIEMKE_NOIBAN`