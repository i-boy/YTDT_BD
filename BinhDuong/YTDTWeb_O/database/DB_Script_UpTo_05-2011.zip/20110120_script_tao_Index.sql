﻿
ALTER TABLE `db_ytdt_bd`.`benh_nhan` MODIFY COLUMN `BENHNHAN_HOTEN` VARCHAR(128) BINARY CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL;

ALTER TABLE `db_ytdt_bd`.`tiep_don` ADD INDEX `Index_tiepdon_sothebh` USING BTREE(tiepdon_sothebh);

ALTER TABLE `db_ytdt_bd`.`benh_nhan` ADD INDEX `Index_benhnhan_hoten` USING BTREE(benhnhan_hoten);

ALTER TABLE `db_ytdt_bd`.`dm_thuoc` DROP INDEX `DMTHUOC_MA`, ADD INDEX `DMTHUOC_MA` USING BTREE(`DMTHUOC_MA`);

ALTER TABLE `db_ytdt_bd`.`dm_benh_vien` DROP INDEX `DMBENHVIEN_MA`, ADD INDEX `DMBENHVIEN_MA` USING BTREE(`DMBENHVIEN_MA`);

