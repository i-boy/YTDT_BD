DROP TABLE IF EXISTS `db_ytdt_bd`.`ct_xuat_bh_thuocBK`;
CREATE TABLE  `db_ytdt_bd`.`ct_xuat_bh_thuocBK` (
  `TONKHO_MA` int(10) unsigned NOT NULL,
  `TIEPDON_MA` varchar(17) character set utf8 collate utf8_unicode_ci NOT NULL,
  `CTXUATBHTD_MALK` varchar(100) character set utf8 collate utf8_unicode_ci default NULL,
  `DMTHUOC_MASO` int(10) unsigned default NULL,
  `THUOCPHONGKHAM_MA` int(11) unsigned default NULL,
  PRIMARY KEY  (`TONKHO_MA`),
  CONSTRAINT `FK_CT_XUAT_BH_TBK_DMTHUOC_MASO` FOREIGN KEY (`DMTHUOC_MASO`) REFERENCES `dm_thuoc` (`DMTHUOC_MASO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

