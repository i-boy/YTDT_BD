DROP VIEW IF EXISTS `db_ytdt_bd`.`v_max_tonkhoma`;
CREATE VIEW `db_ytdt_bd`.`v_max_tonkhoma` AS
  select max(TONKHO_MA) AS TONKHO_MA from ton_kho group by TONKHO_MALIENKET, DMKHOA_MASO;