-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.67-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema db_ytdt_bd
--

CREATE DATABASE IF NOT EXISTS db_ytdt_bd;
USE db_ytdt_bd;

--
-- Definition of table `hsba_chi_tiet_mat`
--

DROP TABLE IF EXISTS `hsba_chi_tiet_mat`;
CREATE TABLE `hsba_chi_tiet_mat` (
  `HSBACTMAT_MA` int(11) NOT NULL auto_increment,
  `HSBACM_MA` int(11) NOT NULL,
  `HSBACTMAT_QTBENHLY` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_TIENSUBENHBT` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_TIENSUBENHGD` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_DD_DIUNG` tinyint(1) default NULL,
  `HSBACTMAT_DD_MATUY` tinyint(1) default NULL,
  `HSBACTMAT_DD_RUOUBIA` tinyint(1) default NULL,
  `HSBACTMAT_DD_THUOCLA` tinyint(1) default NULL,
  `HSBACTMAT_DD_THUOCLAO` tinyint(1) default NULL,
  `HSBACTMAT_DD_KHAC` tinyint(1) default NULL,
  `HSBACTMAT_DD_DIUNG_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_DD_MATUY_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_DD_RUOUBIA_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_DD_THUOCLA_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_DD_THUOCLAO_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_DD_KHAC_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_TUANHOAN` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_HOHAP` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_TIEUHOA` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_THANTIETNIEUSINHHOC` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_THANKINH` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_COXUONGKHOP` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_TMH` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_RHM` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_MAT` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_NT_DD_BLK` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_TTBA` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTMAT_PB` int(10) unsigned default NULL,
  `HSBACTMAT_TIENLUONG` int(10) unsigned default NULL,
  `HSBACTMAT_LYDOVAOV` varchar(512) default NULL,
  `HSBACTMAT_NGAYBENHTHU` int(10) unsigned default NULL,
  `HSBACTMAT_TOANTHAN` varchar(512) default NULL,
  `HSBACTMAT_QTBL_DBLS` varchar(512) default NULL,
  `HSBACTMAT_TTKQXNCLS` varchar(512) default NULL,
  `HSBACTMAT_PPDIEUTRI` varchar(512) default NULL,
  `HSBACTMAT_TTNGUOIBENHRAV` varchar(512) default NULL,
  `HSBACTMAT_HUONGDT_CDTT` varchar(512) default NULL,
  `HSBACTMAT_SOTOXQUANG` int(10) unsigned default NULL,
  `HSBACTMAT_SOTOCTSCANNER` int(10) unsigned default NULL,
  `HSBACTMAT_SOTOSIEUAM` int(10) unsigned default NULL,
  `HSBACTMAT_SOTOXN` int(10) unsigned default NULL,
  `HSBACTMAT_SOTOKHAC` int(10) unsigned default NULL,
  `HSBACTMAT_SOTOLOAIKHAC` varchar(512) default NULL,
  `HSBACTMAT_TONGSOTO` int(10) unsigned default NULL,
  `HSBACTMAT_BSLAMBA` int(10) unsigned default NULL,
  `HSBACTMAT_NGUOIGIAOBA` int(10) unsigned default NULL,
  `HSBACTMAT_NGUOINHANBA` int(10) unsigned default NULL,
  `HSBACTMAT_BSDIEUTRI` int(10) unsigned default NULL,
  `TLKHONGKINH_TRAI` varchar(20) default NULL,
  `TLKHONGKINH_PHAI` varchar(20) default NULL,
  `TLCOKINH_TRAI` varchar(11) default NULL,
  `TLCOKINH_PHAI` varchar(11) default NULL,
  `NHANAP_TRAI` varchar(11) default NULL,
  `NHANAP_PHAI` varchar(11) default NULL,
  `THITRUONG_TRAI` varchar(11) default NULL,
  `THITRUONG_PHAI` varchar(11) default NULL,
  `LEDAO_TRAI` varchar(11) default NULL,
  `LEDAO_PHAI` varchar(11) default NULL,
  `MIMAT_TRAI` varchar(11) default NULL,
  `MIMAT_PHAI` varchar(11) default NULL,
  `HOCMAT_TRAI` varchar(11) default NULL,
  `HOCMAT_PHAI` varchar(11) default NULL,
  `KETMAC_TRAI` varchar(11) default NULL,
  `KETMAC_PHAI` varchar(11) default NULL,
  `GIACMAC_TRAI` varchar(11) default NULL,
  `GIACMAC_PHAI` varchar(11) default NULL,
  `TIENPHONG_TRAI` varchar(11) default NULL,
  `TIENPHONG_PHAI` varchar(11) default NULL,
  `MONGMAT_TRAI` varchar(11) default NULL,
  `MONGMAT_PHAI` varchar(11) default NULL,
  `PHANXADONGTU_TRAI` varchar(11) default NULL,
  `PHANXADONGTU_PHAI` varchar(11) default NULL,
  `THETHUYTINH_TRAI` varchar(11) default NULL,
  `THETHUYTINH_PHAI` varchar(11) default NULL,
  `DICHKINH_TRAI` varchar(11) default NULL,
  `DICHKINH_PHAI` varchar(11) default NULL,
  `SOIANHDONGTU_TRAI` varchar(11) default NULL,
  `SOIANHDONGTU_PHAI` varchar(11) default NULL,
  `TINHHINHNHANCAU_TRAI` varchar(11) default NULL,
  `TINHHINHNHANCAU_PHAI` varchar(11) default NULL,
  `VANDONGNHANCAU_TRAI` varchar(11) default NULL,
  `VANDONGNHANCAU_PHAI` varchar(11) default NULL,
  `DAYMAT_TRAI` varchar(20) default NULL,
  `DAYMAT_PHAI` varchar(20) default NULL,
  `CHITIETCOQUANBENH` varchar(500) default NULL,
  `LEDAO_TRAIMA` varchar(1) default NULL,
  `LEDAO_PHAIMA` varchar(1) default NULL,
  `MIMAT_TRAIMA` varchar(1) default NULL,
  `MIMAT_PHAIMA` varchar(1) default NULL,
  `HOCMAT_TRAIMA` varchar(1) default NULL,
  `HOCMAT_PHAIMA` varchar(1) default NULL,
  `KETMAC_TRAIMA` varchar(1) default NULL,
  `KETMAC_PHAIMA` varchar(1) default NULL,
  `GIACMAC_TRAIMA` varchar(1) default NULL,
  `GIACMAC_PHAIMA` varchar(1) default NULL,
  `TIENPHONG_TRAIMA` varchar(1) default NULL,
  `TIENPHONG_PHAIMA` varchar(1) default NULL,
  `MONGMAT_TRAIMA` varchar(1) default NULL,
  `MONGMAT_PHAIMA` varchar(1) default NULL,
  `PHANXADONGTU_TRAIMA` varchar(1) default NULL,
  `PHANXADONGTU_PHAIMA` varchar(1) default NULL,
  `THETHUYTINH_TRAIMA` varchar(1) default NULL,
  `THETHUYTINH_PHAIMA` varchar(1) default NULL,
  `DICHKINH_TRAIMA` varchar(1) default NULL,
  `DICHKINH_PHAIMA` varchar(1) default NULL,
  `SOIANHDONGTU_TRAIMA` varchar(1) default NULL,
  `SOIANHDONGTU_PHAIMA` varchar(1) default NULL,
  `TINHHINHNHANCAU_TRAIMA` varchar(1) default NULL,
  `TINHHINHNHANCAU_PHAIMA` varchar(1) default NULL,
  `VANDONGNHANCAU_TRAIMA` varchar(1) default NULL,
  `VANDONGNHANCAU_PHAIMA` varchar(1) default NULL,
  `DAYMAT_TRAIMA` varchar(1) default NULL,
  `DAYMAT_PHAIMA` varchar(1) default NULL,
  `HSBACTMAT_COQUANKHAC` varchar(20) default NULL,
  `HSBACTMAT_CHITIETBENHCOQUANKHAC` varchar(500) default NULL,
  `HUYETHOC_MA` varchar(1) default NULL,
  `HUYETHOC_KQ` varchar(200) default NULL,
  `HOASINH_MA` varchar(1) default NULL,
  `HOASINH_KQ` varchar(200) default NULL,
  `VISINH_MA` varchar(1) default NULL,
  `VISINH_KQ` varchar(200) default NULL,
  `XQUANG_MA` varchar(1) default NULL,
  `XQUANG_KQ` varchar(200) default NULL,
  `SIEUAM_MA` varchar(1) default NULL,
  `SIEUAM_KQ` varchar(200) default NULL,
  `NOISOI_MA` varchar(1) default NULL,
  `NOISOI_KQ` varchar(200) default NULL,
  `GPB_MA` varchar(1) default NULL,
  `GPB_KQ` varchar(200) default NULL,
  `XETNGHIEMKHAC_MA` varchar(1) default NULL,
  `XETNGHIEMKHAC_KQ` varchar(200) default NULL,
  `XETNGHIEM_TOMTAT` varchar(500) default NULL,
  `CHDANUONGBENHLY` varchar(20) default NULL,
  `CHDOCHAMSOC` varchar(1) default NULL,
  `GIAIPHAUBENHCHITIET` varchar(100) default NULL,
  `TLRAVKHONGKINH_MT` varchar(10) default NULL,
  `TLRAVKHONGKINH_MP` varchar(10) default NULL,
  `TLRAVCOKINH_MT` varchar(10) default NULL,
  `TLRAVCOKINH_MP` varchar(10) default NULL,
  `NARAV_MP` varchar(10) default NULL,
  `NARAV_MT` varchar(10) default NULL,
  `TTRAV_MP` varchar(10) default NULL,
  `TTRAV_MT` varchar(10) default NULL,
  PRIMARY KEY  (`HSBACTMAT_MA`),
  KEY `FK_HSBA_CHI_TIET_MAT_1` (`HSBACM_MA`),
  KEY `FK_HSBA_CHI_TIET_MAT_2` (`HSBACTMAT_BSLAMBA`),
  KEY `FK_HSBA_CHI_TIET_MAT_3` (`HSBACTMAT_NGUOIGIAOBA`),
  KEY `FK_HSBA_CHI_TIET_MAT_4` (`HSBACTMAT_NGUOINHANBA`),
  KEY `FK_HSBA_CHI_TIET_MAT_5` (`HSBACTMAT_BSDIEUTRI`),
  KEY `FK_HSBA_CHI_TIET_MAT_6` (`HSBACTMAT_TIENLUONG`),
  CONSTRAINT `FK_HSBA_CHI_TIET_MAT_1` FOREIGN KEY (`HSBACM_MA`) REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`),
  CONSTRAINT `FK_HSBA_CHI_TIET_MAT_2` FOREIGN KEY (`HSBACTMAT_BSLAMBA`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`),
  CONSTRAINT `FK_HSBA_CHI_TIET_MAT_3` FOREIGN KEY (`HSBACTMAT_NGUOIGIAOBA`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`),
  CONSTRAINT `FK_HSBA_CHI_TIET_MAT_4` FOREIGN KEY (`HSBACTMAT_NGUOINHANBA`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`),
  CONSTRAINT `FK_HSBA_CHI_TIET_MAT_5` FOREIGN KEY (`HSBACTMAT_BSDIEUTRI`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`),
  CONSTRAINT `FK_HSBA_CHI_TIET_MAT_6` FOREIGN KEY (`HSBACTMAT_TIENLUONG`) REFERENCES `dm_thuoc` (`DMTHUOC_MASO`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
