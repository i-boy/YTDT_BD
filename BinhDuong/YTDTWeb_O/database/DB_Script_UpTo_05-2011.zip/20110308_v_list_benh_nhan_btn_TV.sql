﻿CREATE OR REPLACE VIEW  v_list_benh_nhan_btn
AS
SELECT dmtinh.DMTINH_MA AS TINH_MA,
       dmhuyen.DMHUYEN_MASO AS HUYEN_MASO,
       dmhuyen.DMHUYEN_MA AS HUYEN_MA,
       dmhuyen.DMHUYEN_TEN AS HUYEN_TEN,
       dmxa.DMXA_MASO AS XA_MASO,
       dmxa.DMXA_MA AS XA_MA,
       dmxa.DMXA_TEN AS XA_TEN,
       hsba.BENHNHAN_MA AS BENHNHAN_MA,
       hsba.HSBA_NGAYGIOVAOV AS NGAYGIOVAOV,
       icd.DMBENHICD_MA AS DMBENHICD_MA,
       icdTV.DMBENHICD_MA AS MABENH_TUVONG

FROM hsba
     LEFT JOIN dm_benh_icd icd ON hsba.HSBA_MACHDOANBD = icd.DMBENHICD_MASO
     LEFT JOIN dm_benh_icd icdTV ON hsba.HSBA_TUVONG = icdTV.DMBENHICD_MASO
     LEFT JOIN benh_nhan bn ON hsba.BENHNHAN_MA = bn.BENHNHAN_MA
     LEFT JOIN dm_tinh dmtinh ON bn.TINH_MA = dmtinh.DMTINH_MASO
     LEFT JOIN dm_huyen dmhuyen ON bn.HUYEN_MA = dmhuyen.DMHUYEN_MASO
     LEFT JOIN dm_xa dmxa ON bn.XA_MA = dmxa.DMXA_MASO

WHERE icd.DMBENHICD_MA LIKE 'A00'  -- Ta
      OR icd.DMBENHICD_MA LIKE 'A01'  -- Thuong han
      OR icd.DMBENHICD_MA LIKE 'A03'  -- Ly TT
      OR icd.DMBENHICD_MA LIKE 'A06'  -- Ly amip
      OR icd.DMBENHICD_MA LIKE 'A09'    -- Tieu chay
      OR icd.DMBENHICD_MA LIKE 'A83'    -- Vnao virus
      OR icd.DMBENHICD_MA LIKE 'A84'    -- Vnao virus
      OR icd.DMBENHICD_MA LIKE 'A85'    -- Vnao virus
      OR icd.DMBENHICD_MA LIKE 'A86'    -- Vnao virus
      OR icd.DMBENHICD_MA LIKE 'A87'    -- Vnao virus
      OR icd.DMBENHICD_MA LIKE 'A88'    -- Vnao virus
      OR icd.DMBENHICD_MA LIKE 'A89'    -- Vnao virus
      OR icd.DMBENHICD_MA LIKE 'A90'    -- Sot Dengue
      OR icd.DMBENHICD_MA LIKE 'A91'    -- Sot XH Dengue
      OR icd.DMBENHICD_MA LIKE 'B15'    -- Vgan virus
      OR icd.DMBENHICD_MA LIKE 'B16'    -- Vgan virus
      OR icd.DMBENHICD_MA LIKE 'B17'    -- Vgan virus
      OR icd.DMBENHICD_MA LIKE 'B18'    -- Vgan virus
      OR icd.DMBENHICD_MA LIKE 'B19'    -- Vgan virus
      OR icd.DMBENHICD_MA LIKE 'A82'    -- Benh dai
      OR icd.DMBENHICD_MA LIKE 'A39.0'    -- VMN mo cau
      OR icd.DMBENHICD_MA LIKE 'B01'    -- Thuy dau
      OR icd.DMBENHICD_MA LIKE 'B02'    -- Thuy dau
      OR icd.DMBENHICD_MA LIKE 'A36'    -- Bach hau
      OR icd.DMBENHICD_MA LIKE 'A37'    -- Ho ga
      OR icd.DMBENHICD_MA LIKE 'A33'    -- Uon van SS
      OR icd.DMBENHICD_MA LIKE 'A35'    -- Uon van khac
      OR icd.DMBENHICD_MA LIKE 'A80'    -- Liet mem cap va nghi bai liet
      OR icd.DMBENHICD_MA LIKE 'B05'    -- Soi
      OR icd.DMBENHICD_MA LIKE 'B26'    -- Quai bi
      OR icd.DMBENHICD_MA LIKE 'J10'    -- Cum
      OR icd.DMBENHICD_MA LIKE 'J11'    -- Cum
      OR icd.DMBENHICD_MA LIKE 'B30'    -- APC
      OR icd.DMBENHICD_MA LIKE 'A20'    -- Dich hach
      OR icd.DMBENHICD_MA LIKE 'A22'    -- Than
      OR icd.DMBENHICD_MA LIKE 'A27'    -- Leptospira
	  OR icdTV.DMBENHICD_MA LIKE 'A00'  -- Ta
      OR icdTV.DMBENHICD_MA LIKE 'A01'  -- Thuong han
      OR icdTV.DMBENHICD_MA LIKE 'A03'  -- Ly TT
      OR icdTV.DMBENHICD_MA LIKE 'A06'  -- Ly amip
      OR icdTV.DMBENHICD_MA LIKE 'A09'    -- Tieu chay
      OR icdTV.DMBENHICD_MA LIKE 'A83'    -- Vnao virus
      OR icdTV.DMBENHICD_MA LIKE 'A84'    -- Vnao virus
      OR icdTV.DMBENHICD_MA LIKE 'A85'    -- Vnao virus
      OR icdTV.DMBENHICD_MA LIKE 'A86'    -- Vnao virus
      OR icdTV.DMBENHICD_MA LIKE 'A87'    -- Vnao virus
      OR icdTV.DMBENHICD_MA LIKE 'A88'    -- Vnao virus
      OR icdTV.DMBENHICD_MA LIKE 'A89'    -- Vnao virus
      OR icdTV.DMBENHICD_MA LIKE 'A90'    -- Sot Dengue
      OR icdTV.DMBENHICD_MA LIKE 'A91'    -- Sot XH Dengue
      OR icdTV.DMBENHICD_MA LIKE 'B15'    -- Vgan virus
      OR icdTV.DMBENHICD_MA LIKE 'B16'    -- Vgan virus
      OR icdTV.DMBENHICD_MA LIKE 'B17'    -- Vgan virus
      OR icdTV.DMBENHICD_MA LIKE 'B18'    -- Vgan virus
      OR icdTV.DMBENHICD_MA LIKE 'B19'    -- Vgan virus
      OR icdTV.DMBENHICD_MA LIKE 'A82'    -- Benh dai
      OR icdTV.DMBENHICD_MA LIKE 'A39.0'    -- VMN mo cau
      OR icdTV.DMBENHICD_MA LIKE 'B01'    -- Thuy dau
      OR icdTV.DMBENHICD_MA LIKE 'B02'    -- Thuy dau
      OR icdTV.DMBENHICD_MA LIKE 'A36'    -- Bach hau
      OR icdTV.DMBENHICD_MA LIKE 'A37'    -- Ho ga
      OR icdTV.DMBENHICD_MA LIKE 'A33'    -- Uon van SS
      OR icdTV.DMBENHICD_MA LIKE 'A35'    -- Uon van khac
      OR icdTV.DMBENHICD_MA LIKE 'A80'    -- Liet mem cap va nghi bai liet
      OR icdTV.DMBENHICD_MA LIKE 'B05'    -- Soi
      OR icdTV.DMBENHICD_MA LIKE 'B26'    -- Quai bi
      OR icdTV.DMBENHICD_MA LIKE 'J10'    -- Cum
      OR icdTV.DMBENHICD_MA LIKE 'J11'    -- Cum
      OR icdTV.DMBENHICD_MA LIKE 'B30'    -- APC
      OR icdTV.DMBENHICD_MA LIKE 'A20'    -- Dich hach
      OR icdTV.DMBENHICD_MA LIKE 'A22'    -- Than
      OR icdTV.DMBENHICD_MA LIKE 'A27'    -- Leptospira
      -- Thieu H.chung ly
      -- Thieu H/c tay chan mieng
;