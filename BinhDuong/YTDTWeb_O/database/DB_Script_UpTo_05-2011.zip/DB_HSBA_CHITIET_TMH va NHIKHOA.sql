-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.67-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema db_ytdt_bd
--

CREATE DATABASE IF NOT EXISTS db_ytdt_bd;
USE db_ytdt_bd;

--
-- Definition of table `hsba_chi_tiet_nhikhoa`
--

DROP TABLE IF EXISTS `hsba_chi_tiet_nhikhoa`;
CREATE TABLE `hsba_chi_tiet_nhikhoa` (
  `HSBACTNHIKHOA_MA` int(11) NOT NULL auto_increment,
  `HSBACM_MA` int(11) NOT NULL,
  `HSBACTNHIKHOA_QTBENHLY` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTNHIKHOA_TIENSUBENHBT` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTNHIKHOA_TIENSUBENHGD` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTNHIKHOA_TUANHOAN` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTNHIKHOA_HOHAP` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTNHIKHOA_TIEUHOA` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTNHIKHOA_THANTIETNIEUSINHHOC` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTNHIKHOA_THANKINH` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTNHIKHOA_COXUONGKHOP` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTNHIKHOA_TMH_RHM_MAT_DINHDUONG_KHAC` varchar(512) default NULL,
  `HSBACTNHIKHOA_TTBA` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTNHIKHOA_TIENLUONG` varchar(255) default NULL,
  `HSBACTNHIKHOA_LYDOVAOV` varchar(512) default NULL,
  `HSBACTNHIKHOA_NGAYBENHTHU` int(10) unsigned default NULL,
  `HSBACTNHIKHOA_TOANTHAN` varchar(512) default NULL,
  `HSBACTNHIKHOA_QTBL_DBLS` varchar(512) default NULL,
  `HSBACTNHIKHOA_TTKQXNCLS` varchar(512) default NULL,
  `HSBACTNHIKHOA_PPDIEUTRI` varchar(512) default NULL,
  `HSBACTNHIKHOA_TTNGUOIBENHRAV` varchar(512) default NULL,
  `HSBACTNHIKHOA_HUONGDT_CDTT` varchar(512) default NULL,
  `HSBACTNHIKHOA_SOTOXQUANG` int(10) unsigned default NULL,
  `HSBACTNHIKHOA_SOTOCTSCANNER` int(10) unsigned default NULL,
  `HSBACTNHIKHOA_SOTOSIEUAM` int(10) unsigned default NULL,
  `HSBACTNHIKHOA_SOTOXN` int(10) unsigned default NULL,
  `HSBACTNHIKHOA_SOTOKHAC` int(10) unsigned default NULL,
  `HSBACTNHIKHOA_SOTOLOAIKHAC` varchar(512) default NULL,
  `HSBACTNHIKHOA_TONGSOTO` int(10) unsigned default NULL,
  `HSBACTNHIKHOA_BSLAMBA` int(10) unsigned default NULL,
  `HSBACTNHIKHOA_NGUOIGIAOBA` int(10) unsigned default NULL,
  `HSBACTNHIKHOA_NGUOINHANBA` int(10) unsigned default NULL,
  `HSBACTNHIKHOA_BSDIEUTRI` int(10) unsigned default NULL,
  `HSBACTNHIKHOA_HOTEN_BO` varchar(255) default NULL,
  `HSBACTNHIKHOA_HOTEN_ME` varchar(255) default NULL,
  `HSBACTNHIKHOA_TDVH_BO` varchar(50) default NULL,
  `HSBACTNHIKHOA_TDVH_ME` varchar(50) default NULL,
  `HSBACTNHIKHOA_NGHENGHIEP_BO` varchar(100) default NULL,
  `HSBACTNHIKHOA_NGHENGHIEP_ME` varchar(100) default NULL,
  `HSBACTNHIKHOA_CONTHUMAY` varchar(5) default NULL,
  `HSBACTNHIKHOA_SINHDUTHANG` tinyint(1) default NULL,
  `HSBACTNHIKHOA_SINHDENON` tinyint(1) default NULL,
  `HSBACTNHIKHOA_SINHNAOHUT` tinyint(1) default NULL,
  `HSBACTNHIKHOA_SINHSONG` tinyint(1) default NULL,
  `HSBACTNHIKHOA_DETHUONG` tinyint(1) default NULL,
  `HSBACTNHIKHOA_FORCEPS` tinyint(1) default NULL,
  `HSBACTNHIKHOA_GIACHUT` tinyint(1) default NULL,
  `HSBACTNHIKHOA_DEPHAUTHUAT` tinyint(1) default NULL,
  `HSBACTNHIKHOA_DECHIHUY` tinyint(1) default NULL,
  `HSBACTNHIKHOA_DEKHAC` tinyint(1) default NULL,
  `HSBACTNHIKHOA_CANNANGLUCSINH` varchar(20) default NULL,
  `HSBACTNHIKHOA_DITATBAMSINH` tinyint(1) default NULL,
  `HSBACTNHIKHOA_TATBAMSINH` varchar(255) default NULL,
  `HSBACTNHIKHOA_PT_TINHTHAN` varchar(255) default NULL,
  `HSBACTNHIKHOA_PT_VANDONG` varchar(255) default NULL,
  `HSBACTNHIKHOA_SINHTRUONG_BLKHAC` varchar(255) default NULL,
  `HSBACTNHIKHOA_NUOIDUONG_SUAME` tinyint(1) default NULL,
  `HSBACTNHIKHOA_NUOIDUONG_NHANTAO` tinyint(1) default NULL,
  `HSBACTNHIKHOA_NUOIDUONG_HONHOP` tinyint(1) default NULL,
  `HSBACTNHIKHOA_CAISUATHANGTHU` varchar(20) default NULL,
  `HSBACTNHIKHOA_CHAMSOC_TAINHATRE` tinyint(1) default NULL,
  `HSBACTNHIKHOA_CHAMSOC_TAINHA` tinyint(1) default NULL,
  `HSBACTNHIKHOA_TIEMCHUNG_LAO` tinyint(1) default NULL,
  `HSBACTNHIKHOA_TIEMCHUNG_BAILIET` tinyint(1) default NULL,
  `HSBACTNHIKHOA_TIEMCHUNG_SOI` tinyint(1) default NULL,
  `HSBACTNHIKHOA_TIEMCHUNG_HOGA` tinyint(1) default NULL,
  `HSBACTNHIKHOA_TIEMCHUNG_UONVAN` tinyint(1) default NULL,
  `HSBACTNHIKHOA_TIEMCHUNG_BACHHAU` tinyint(1) default NULL,
  `HSBACTNHIKHOA_TIEMCHUNG_KHAC` tinyint(1) default NULL,
  `HSBACTNHIKHOA_BENHKHACDUOCTIEMCHUNG` varchar(255) default NULL,
  `HSBACTNHIKHOA_CHIEUCAO` varchar(20) default NULL,
  `HSBACTNHIKHOA_VONGNGUC` varchar(20) default NULL,
  `HSBACTNHIKHOA_VONGDAU` varchar(20) default NULL,
  `HSBACTNHIKHOA_XETNGHIEMCANLAM` varchar(255) default NULL,
  `HSBACTNHIKHOA_HUONGDIEUTRI` varchar(255) default NULL,
  PRIMARY KEY  (`HSBACTNHIKHOA_MA`),
  KEY `FK_HSBA_CHI_TIET_NHIKHOA_1` (`HSBACM_MA`),
  KEY `FK_HSBA_CHI_TIET_NHIKHOA_3` (`HSBACTNHIKHOA_BSLAMBA`),
  KEY `FK_HSBA_CHI_TIET_NHIKHOA_4` (`HSBACTNHIKHOA_NGUOIGIAOBA`),
  KEY `FK_HSBA_CHI_TIET_NHIKHOA_5` (`HSBACTNHIKHOA_NGUOINHANBA`),
  KEY `FK_HSBA_CHI_TIET_NHIKHOA_6` (`HSBACTNHIKHOA_BSDIEUTRI`),
  CONSTRAINT `FK_HSBA_CHI_TIET_NHIKHOA_1` FOREIGN KEY (`HSBACM_MA`) REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`),
  CONSTRAINT `FK_HSBA_CHI_TIET_NHIKHOA_3` FOREIGN KEY (`HSBACTNHIKHOA_BSLAMBA`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`),
  CONSTRAINT `FK_HSBA_CHI_TIET_NHIKHOA_4` FOREIGN KEY (`HSBACTNHIKHOA_NGUOIGIAOBA`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`),
  CONSTRAINT `FK_HSBA_CHI_TIET_NHIKHOA_5` FOREIGN KEY (`HSBACTNHIKHOA_NGUOINHANBA`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`),
  CONSTRAINT `FK_HSBA_CHI_TIET_NHIKHOA_6` FOREIGN KEY (`HSBACTNHIKHOA_BSDIEUTRI`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='InnoDB free: 7168 kB; (`HSBACM_MA`) REFER `DB_YTDT_BD/HSBA_C';


--
-- Definition of table `hsba_chi_tiet_tmh`
--

DROP TABLE IF EXISTS `hsba_chi_tiet_tmh`;
CREATE TABLE `hsba_chi_tiet_tmh` (
  `HSBACTTMH_MA` int(11) NOT NULL auto_increment,
  `HSBACM_MA` int(11) NOT NULL,
  `HSBACTTMH_QTBENHLY` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_TIENSUBENHBT` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_TIENSUBENHGD` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_DD_DIUNG` tinyint(1) default NULL,
  `HSBACTTMH_DD_MATUY` tinyint(1) default NULL,
  `HSBACTTMH_DD_RUOUBIA` tinyint(1) default NULL,
  `HSBACTTMH_DD_THUOCLA` tinyint(1) default NULL,
  `HSBACTTMH_DD_THUOCLAO` tinyint(1) default NULL,
  `HSBACTTMH_DD_KHAC` tinyint(1) default NULL,
  `HSBACTTMH_DD_DIUNG_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_DD_MATUY_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_DD_RUOUBIA_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_DD_THUOCLA_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_DD_THUOCLAO_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_DD_KHAC_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_TUANHOAN` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_HOHAP` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_TIEUHOA` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_THANTIETNIEUSINHHOC` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_THANKINH` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_COXUONGKHOP` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_RHM` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_MAT` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_TIENDINH` varchar(20) default NULL,
  `HSBACTTMH_TTBA` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTTMH_PB` int(10) unsigned default NULL,
  `HSBACTTMH_TIENLUONG` varchar(255) default NULL,
  `HSBACTTMH_LYDOVAOV` varchar(512) default NULL,
  `HSBACTTMH_NGAYBENHTHU` int(10) unsigned default NULL,
  `HSBACTTMH_TOANTHAN` varchar(512) default NULL,
  `HSBACTTMH_QTBL_DBLS` varchar(512) default NULL,
  `HSBACTTMH_TTKQXNCLS` varchar(512) default NULL,
  `HSBACTTMH_PPDIEUTRI` varchar(512) default NULL,
  `HSBACTTMH_TTNGUOIBENHRAV` varchar(512) default NULL,
  `HSBACTTMH_HUONGDT_CDTT` varchar(512) default NULL,
  `HSBACTTMH_SOTOXQUANG` int(10) unsigned default NULL,
  `HSBACTTMH_SOTOCTSCANNER` int(10) unsigned default NULL,
  `HSBACTTMH_SOTOSIEUAM` int(10) unsigned default NULL,
  `HSBACTTMH_SOTOXN` int(10) unsigned default NULL,
  `HSBACTTMH_SOTOKHAC` int(10) unsigned default NULL,
  `HSBACTTMH_SOTOLOAIKHAC` varchar(512) default NULL,
  `HSBACTTMH_TONGSOTO` int(10) unsigned default NULL,
  `HSBACTTMH_BSLAMBA` int(10) unsigned default NULL,
  `HSBACTTMH_NGUOIGIAOBA` int(10) unsigned default NULL,
  `HSBACTTMH_NGUOINHANBA` int(10) unsigned default NULL,
  `HSBACTTMH_BSDIEUTRI` int(10) unsigned default NULL,
  `CHITIETCOQUANBENH` varchar(500) default NULL,
  `HSBACTTMH_CHITIETBENHCOQUANKHAC` varchar(500) default NULL,
  `HUYETHOC_MA` varchar(1) default NULL,
  `HUYETHOC_KQ` varchar(200) default NULL,
  `HOASINH_MA` varchar(1) default NULL,
  `HOASINH_KQ` varchar(200) default NULL,
  `VISINH_MA` varchar(1) default NULL,
  `VISINH_KQ` varchar(200) default NULL,
  `XQUANG_MA` varchar(1) default NULL,
  `XQUANG_KQ` varchar(200) default NULL,
  `SIEUAM_MA` varchar(1) default NULL,
  `SIEUAM_KQ` varchar(200) default NULL,
  `NOISOI_MA` varchar(1) default NULL,
  `NOISOI_KQ` varchar(200) default NULL,
  `GPB_MA` varchar(1) default NULL,
  `GPB_KQ` varchar(200) default NULL,
  `XETNGHIEMKHAC_MA` varchar(1) default NULL,
  `XETNGHIEMKHAC_KQ` varchar(200) default NULL,
  `XETNGHIEM_TOMTAT` varchar(500) default NULL,
  `CHDANUONGBENHLY` varchar(20) default NULL,
  `CHDOCHAMSOC` varchar(1) default NULL,
  `GIAIPHAUBENHCHITIET` varchar(100) default NULL,
  PRIMARY KEY  (`HSBACTTMH_MA`),
  KEY `FK_hsba_chi_tiet_tmh_1` (`HSBACM_MA`),
  KEY `FK_hsba_chi_tiet_tmh_2` (`HSBACTTMH_BSLAMBA`),
  KEY `FK_hsba_chi_tiet_tmh_3` (`HSBACTTMH_NGUOIGIAOBA`),
  KEY `FK_hsba_chi_tiet_tmh_4` (`HSBACTTMH_NGUOINHANBA`),
  KEY `FK_hsba_chi_tiet_tmh_5` (`HSBACTTMH_BSDIEUTRI`),
  KEY `FK_hsba_chi_tiet_tmh_6` (`HSBACTTMH_TIENLUONG`),
  CONSTRAINT `FK_hsba_chi_tiet_tmh_1` FOREIGN KEY (`HSBACM_MA`) REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`),
  CONSTRAINT `FK_hsba_chi_tiet_tmh_2` FOREIGN KEY (`HSBACTTMH_BSLAMBA`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`),
  CONSTRAINT `FK_hsba_chi_tiet_tmh_3` FOREIGN KEY (`HSBACTTMH_NGUOIGIAOBA`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`),
  CONSTRAINT `FK_hsba_chi_tiet_tmh_4` FOREIGN KEY (`HSBACTTMH_NGUOINHANBA`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`),
  CONSTRAINT `FK_hsba_chi_tiet_tmh_5` FOREIGN KEY (`HSBACTTMH_BSDIEUTRI`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
