DROP VIEW IF EXISTS `db_ytdt_bd`.`v_tonkho_khoa_hientai`;
CREATE VIEW `db_ytdt_bd`.`v_tonkho_khoa_hientai` AS
  select tk.* from ton_kho tk, v_max_tonkhoma as lst
where tk.TONKHO_MA =  lst.TONKHO_MA
order by tk.DMKHOA_MASO;