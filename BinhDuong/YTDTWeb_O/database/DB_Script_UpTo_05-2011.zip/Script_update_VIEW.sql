﻿-- View: v_benh_nhan_sonde
CREATE OR REPLACE VIEW  v_benh_nhan_sonde
AS
Select  pba.`PHIEUBAOAN_MASO` AS PHIEUBAOAN_MASO,
        bnpba.`BNPBA_MASO` AS BNPBA_MASO,
		bnpba.`BNPBA_PHUTROI` AS BNPBA_PHUTROI,
		bnpba.`DTDMLA2_MASO` AS DTDMLA2_MASO,
        pba.`PHIEUBAOAN_NGAYAN` AS NGAYAN
FROM phieu_bao_an pba LEFT JOIN benh_nhan_phieu_bao_an bnpba ON pba.`PHIEUBAOAN_MASO` = bnpba.`PHIEUBAOAN_MASO`
WHERE bnpba.`DTDMLA_MASO` = 1  -- Khau phan
      AND bnpba.`DTDMLA2_MASO` = 1; -- An qua sonde

-- View: v_benh_nhan_chao	  
CREATE OR REPLACE VIEW  v_benh_nhan_chao
AS
Select  pba.`PHIEUBAOAN_MASO` AS PHIEUBAOAN_MASO,
        bnpba.`BNPBA_MASO` AS BNPBA_MASO,
		bnpba.`BNPBA_PHUTROI` AS BNPBA_PHUTROI,
		bnpba.`DTDMLA2_MASO` AS DTDMLA2_MASO,
        pba.`PHIEUBAOAN_NGAYAN` AS NGAYAN
FROM phieu_bao_an pba LEFT JOIN benh_nhan_phieu_bao_an bnpba ON pba.`PHIEUBAOAN_MASO` = bnpba.`PHIEUBAOAN_MASO`
WHERE bnpba.`DTDMLA_MASO` = 1  -- Khau phan
      AND bnpba.`DTDMLA2_MASO` = 2; -- An chao	  
	  
-- View: v_benh_nhan_com	  
CREATE OR REPLACE VIEW  v_benh_nhan_com
AS
Select  pba.`PHIEUBAOAN_MASO` AS PHIEUBAOAN_MASO,
        bnpba.`BNPBA_MASO` AS BNPBA_MASO,
		bnpba.`BNPBA_PHUTROI` AS BNPBA_PHUTROI,
		bnpba.`DTDMLA2_MASO` AS DTDMLA2_MASO,
        pba.`PHIEUBAOAN_NGAYAN` AS NGAYAN
FROM phieu_bao_an pba LEFT JOIN benh_nhan_phieu_bao_an bnpba ON pba.`PHIEUBAOAN_MASO` = bnpba.`PHIEUBAOAN_MASO`
WHERE bnpba.`DTDMLA_MASO` = 1  -- Khau phan
      AND bnpba.`DTDMLA2_MASO` = 3; -- An com	
	  
-- View : v_benh_nhan_gio_an , Su dung trong report Phieu bao giao khau phan an cho to tiet che
CREATE OR REPLACE VIEW  v_benh_nhan_gio_an
AS
SELECT bnga.`BNPBA_MASO` AS BNPBA_MASO,
       bnga.`DTDMGA_MASO` AS DTDMGA_MASO,
       bnpba.`DTDMLA2_MASO`, pba.`PHIEUBAOAN_NGAYAN` AS NGAYAN
FROM benh_nhan_gio_an bnga LEFT JOIN benh_nhan_phieu_bao_an bnpba ON bnga.`BNPBA_MASO` = bnpba.`BNPBA_MASO`
    LEFT JOIN phieu_bao_an pba ON bnpba.`PHIEUBAOAN_MASO` = pba.`PHIEUBAOAN_MASO`;

-- View : v_count_sonde_dd_6h : Count so benh nhan an qua sonde, che do an DD vao luc 6h
CREATE OR REPLACE VIEW  v_count_sonde_dd_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_DD_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 2 -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_dd_6h : Count so benh nhan an qua sonde, che do an DD va co an 1 trong cac che do an khac, vao luc 6h
CREATE OR REPLACE VIEW  v_has_sonde_dd_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_DD_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 2 -- -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_sonde_dd_11h : Count so benh nhan an qua sonde, che do an DD vao luc 11h
CREATE OR REPLACE VIEW  v_count_sonde_dd_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_DD_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 2 -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_dd_11h : Count so benh nhan an qua sonde, che do an DD va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_sonde_dd_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_DD_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 2 -- -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_sonde_dd_16h : Count so benh nhan an qua sonde, che do an DD vao luc 16h
CREATE OR REPLACE VIEW  v_count_sonde_dd_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_DD_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 2 -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_dd_16h : Count so benh nhan an qua sonde, che do an DD va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_sonde_dd_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_DD_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 2 -- -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_sonde_dd_20h : Count so benh nhan an qua sonde, che do an DD vao luc 20h
CREATE OR REPLACE VIEW  v_count_sonde_dd_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_DD_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 2 -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_dd_20h : Count so benh nhan an qua sonde, che do an DD va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_sonde_dd_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_DD_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 2 -- -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;
-- ##########################################################

-- View : v_count_sonde_stm_6h : Count so benh nhan an qua sonde, che do an STM (khong co che do DD) vao luc 6h
CREATE OR REPLACE VIEW  v_count_sonde_stm_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_STM_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 3 -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_stm_6h : Count so benh nhan an qua sonde, che do an STM va co an 1 trong cac che do an khac (khong co che do DD), vao luc 6h
CREATE OR REPLACE VIEW  v_has_sonde_stm_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_STM_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 3 -- -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD  
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_sonde_stm_11h : Count so benh nhan an qua sonde, che do an STM vao luc 11h
CREATE OR REPLACE VIEW  v_count_sonde_stm_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_STM_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 3 -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_stm_11h : Count so benh nhan an qua sonde, che do an STM va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_sonde_stm_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_STM_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 3 -- -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD  
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_sonde_stm_16h : Count so benh nhan an qua sonde, che do an STM vao luc 16h
CREATE OR REPLACE VIEW  v_count_sonde_stm_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_STM_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 3 -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_stm_16h : Count so benh nhan an qua sonde, che do an STM va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_sonde_stm_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_STM_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 3 -- -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD  
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_sonde_stm_20h : Count so benh nhan an qua sonde, che do an STM vao luc 20h
CREATE OR REPLACE VIEW  v_count_sonde_stm_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_STM_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 3 -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_stm_20h : Count so benh nhan an qua sonde, che do an STM va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_sonde_stm_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_STM_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 3 -- -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD  
	)
GROUP BY v_bnga.`NGAYAN`;

-- ##########################################################

-- View : v_count_sonde_cm_6h : Count so benh nhan an qua sonde, che do an CM (khong co che do DD, STM) vao luc 6h
CREATE OR REPLACE VIEW  v_count_sonde_cm_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_CM_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 5 -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_cm_6h : Count so benh nhan an qua sonde, che do an CM va co an 1 trong cac che do an khac (khong co che do DD,STM), vao luc 6h
CREATE OR REPLACE VIEW  v_has_sonde_cm_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_CM_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 5 -- -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM  
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_sonde_cm_11h : Count so benh nhan an qua sonde, che do an CM vao luc 11h
CREATE OR REPLACE VIEW  v_count_sonde_cm_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_CM_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 5 -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_cm_11h : Count so benh nhan an qua sonde, che do an CM va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_sonde_cm_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_CM_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 5 -- -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD, STM  
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_sonde_cm_16h : Count so benh nhan an qua sonde, che do an CM vao luc 16h
CREATE OR REPLACE VIEW  v_count_sonde_cm_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_CM_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 5 -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_cm_16h : Count so benh nhan an qua sonde, che do an CM va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_sonde_cm_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_CM_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 5 -- -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD, STM  
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_sonde_cm_20h : Count so benh nhan an qua sonde, che do an CM vao luc 20h
CREATE OR REPLACE VIEW  v_count_sonde_cm_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_CM_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 5 -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_cm_20h : Count so benh nhan an qua sonde, che do an CM va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_sonde_cm_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_CM_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 5 -- -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD, STM  
	)
GROUP BY v_bnga.`NGAYAN`;

-- ##########################################################

-- View : v_count_sonde_lat_6h : Count so benh nhan an qua sonde, che do an LAT (khong co che do DD, STM,CM) vao luc 6h
CREATE OR REPLACE VIEW  v_count_sonde_lat_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_LAT_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM,CM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_lat_6h : Count so benh nhan an qua sonde, che do an LAT va co an 1 trong cac che do an khac (khong co che do DD,STM,CM), vao luc 6h
CREATE OR REPLACE VIEW  v_has_sonde_lat_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_LAT_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 1 -- -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM, CM  
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_sonde_lat_11h : Count so benh nhan an qua sonde, che do an LAT vao luc 11h
CREATE OR REPLACE VIEW  v_count_sonde_lat_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_LAT_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM,CM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_lat_11h : Count so benh nhan an qua sonde, che do an LAT va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_sonde_lat_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_LAT_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD, STM ,CM 
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_sonde_lat_16h : Count so benh nhan an qua sonde, che do an LAT vao luc 16h
CREATE OR REPLACE VIEW  v_count_sonde_lat_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_LAT_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM,CM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_lat_16h : Count so benh nhan an qua sonde, che do an LAT va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_sonde_lat_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_LAT_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 1  -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD, STM, CM  
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_sonde_lat_20h : Count so benh nhan an qua sonde, che do an LAT vao luc 20h
CREATE OR REPLACE VIEW  v_count_sonde_lat_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_LAT_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM,CM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_lat_20h : Count so benh nhan an qua sonde, che do an LAT va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_sonde_lat_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_LAT_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 1 -- -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD, STM,CM  
	)
GROUP BY v_bnga.`NGAYAN`;

-- ##########################################################

-- View : v_count_sonde_thg_6h : Count so benh nhan an qua sonde, che do an THUONG (khong co che do DD, STM,CM, LAT) vao luc 6h
CREATE OR REPLACE VIEW  v_count_sonde_thg_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_THG_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM,CM,LAT
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_thg_6h : Count so benh nhan an qua sonde, che do an THUONG va co an 1 trong cac che do an khac (khong co che do DD,STM,CM,LAT), vao luc 6h
CREATE OR REPLACE VIEW  v_has_sonde_thg_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_THG_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM, CM, LAT  
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_sonde_thg_11h : Count so benh nhan an qua sonde, che do an THUONG vao luc 11h
CREATE OR REPLACE VIEW  v_count_sonde_thg_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_THG_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM,CM, LAT
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_thg_11h : Count so benh nhan an qua sonde, che do an THUONG va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_sonde_thg_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_THG_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD, STM ,CM, LAT 
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_sonde_thg_16h : Count so benh nhan an qua sonde, che do an THUONG vao luc 16h
CREATE OR REPLACE VIEW  v_count_sonde_thg_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_THG_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM,CM,LAT
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_thg_16h : Count so benh nhan an qua sonde, che do an THUONG va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_sonde_thg_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_THG_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 4  -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD, STM, CM, LAT  
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_sonde_thg_20h : Count so benh nhan an qua sonde, che do an THUONG vao luc 20h
CREATE OR REPLACE VIEW  v_count_sonde_thg_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_SONDE_THG_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
	AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM,CM,LAT
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_sonde_thg_20h : Count so benh nhan an qua sonde, che do an THUONG va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_sonde_thg_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_SONDE_THG_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 1 -- DTDMLA2_MASO = 1 (loai an qua sonde)
    )
	  AND bncda.`DTDMCDA_MASO` = 4 -- -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD, STM,CM  
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_chao_dd_6h : Count so benh nhan an chao, che do an DD vao luc 6h
CREATE OR REPLACE VIEW  v_count_chao_dd_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_DD_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 2 -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_dd_6h : Count so benh nhan an chao, che do an DD va co an 1 trong cac che do an khac, vao luc 6h
CREATE OR REPLACE VIEW  v_has_chao_dd_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_DD_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 2 -- -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_chao_dd_11h : Count so benh nhan an chao, che do an DD vao luc 11h
CREATE OR REPLACE VIEW  v_count_chao_dd_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_DD_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 2 -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_dd_11h : Count so benh nhan an chao, che do an DD va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_chao_dd_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_DD_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an qua chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 2 -- -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_chao_dd_16h : Count so benh nhan an chao, che do an DD vao luc 16h
CREATE OR REPLACE VIEW  v_count_chao_dd_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_DD_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an qua chao)
	AND bncda.`DTDMCDA_MASO` = 2 -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_dd_16h : Count so benh nhan an chao, che do an DD va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_chao_dd_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_DD_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 2 -- -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_chao_dd_20h : Count so benh nhan an chao, che do an DD vao luc 20h
CREATE OR REPLACE VIEW  v_count_chao_dd_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_DD_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an qua chao)
	AND bncda.`DTDMCDA_MASO` = 2 -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_dd_20h : Count so benh nhan an chao, che do an DD va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_chao_dd_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_DD_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an qua chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 2 -- -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;
-- ##########################################################

-- View : v_count_chao_stm_6h : Count so benh nhan an chao, che do an STM (khong co che do DD) vao luc 6h
CREATE OR REPLACE VIEW  v_count_chao_stm_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_STM_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 3 -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_stm_6h : Count so benh nhan an chao, che do an STM va co an 1 trong cac che do an khac (khong co che do DD), vao luc 6h
CREATE OR REPLACE VIEW  v_has_chao_stm_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_STM_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 3 -- -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_chao_stm_11h : Count so benh nhan an chao, che do an STM vao luc 11h
CREATE OR REPLACE VIEW  v_count_chao_stm_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_STM_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 3 -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_stm_11h : Count so benh nhan an chao, che do an STM va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_chao_stm_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_STM_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 3 -- -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_chao_stm_16h : Count so benh nhan an chao, che do an STM vao luc 16h
CREATE OR REPLACE VIEW  v_count_chao_stm_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_STM_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 3 -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_stm_16h : Count so benh nhan an chao, che do an STM va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_chao_stm_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_STM_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 3 -- -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_chao_stm_20h : Count so benh nhan an chao, che do an STM vao luc 20h
CREATE OR REPLACE VIEW  v_count_chao_stm_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_STM_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 3 -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_stm_20h : Count so benh nhan an chao, che do an STM va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_chao_stm_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_STM_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 3 -- -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
	)
GROUP BY v_bnga.`NGAYAN`;

-- ##########################################################

-- View : v_count_chao_cm_6h : Count so benh nhan an chao, che do an CM (khong co che do DD, STM) vao luc 6h
CREATE OR REPLACE VIEW  v_count_chao_cm_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_CM_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 5 -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_cm_6h : Count so benh nhan an chao, che do an CM va co an 1 trong cac che do an khac (khong co che do DD,STM), vao luc 6h
CREATE OR REPLACE VIEW  v_has_chao_cm_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_CM_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an qua chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 5 -- -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_chao_cm_11h : Count so benh nhan an chao, che do an CM vao luc 11h
CREATE OR REPLACE VIEW  v_count_chao_cm_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_CM_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 5 -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_cm_11h : Count so benh nhan an chao, che do an CM va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_chao_cm_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_CM_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 5 -- -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD, STM
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_chao_cm_16h : Count so benh nhan an chao, che do an CM vao luc 16h
CREATE OR REPLACE VIEW  v_count_chao_cm_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_CM_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 5 -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_cm_16h : Count so benh nhan an chao, che do an CM va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_chao_cm_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_CM_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 5 -- -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD, STM
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_chao_cm_20h : Count so benh nhan an chao, che do an CM vao luc 20h
CREATE OR REPLACE VIEW  v_count_chao_cm_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_CM_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 5 -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_cm_20h : Count so benh nhan an chao, che do an CM va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_chao_cm_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_CM_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 5 -- -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD, STM
	)
GROUP BY v_bnga.`NGAYAN`;

-- ##########################################################

-- View : v_count_chao_lat_6h : Count so benh nhan an chao, che do an LAT (khong co che do DD, STM,CM) vao luc 6h
CREATE OR REPLACE VIEW  v_count_chao_lat_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_LAT_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM,CM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_lat_6h : Count so benh nhan an chao, che do an LAT va co an 1 trong cac che do an khac (khong co che do DD,STM,CM), vao luc 6h
CREATE OR REPLACE VIEW  v_has_chao_lat_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_LAT_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 1 -- -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM, CM
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_chao_lat_11h : Count so benh nhan an chao, che do an LAT vao luc 11h
CREATE OR REPLACE VIEW  v_count_chao_lat_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_LAT_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM,CM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_lat_11h : Count so benh nhan an chao, che do an LAT va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_chao_lat_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_LAT_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD, STM ,CM
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_chao_lat_16h : Count so benh nhan an chao, che do an LAT vao luc 16h
CREATE OR REPLACE VIEW  v_count_chao_lat_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_LAT_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM,CM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_lat_16h : Count so benh nhan an chao, che do an LAT va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_chao_lat_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_LAT_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 1  -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD, STM, CM
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_chao_lat_20h : Count so benh nhan an chao, che do an LAT vao luc 20h
CREATE OR REPLACE VIEW  v_count_chao_lat_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_LAT_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM,CM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_lat_20h : Count so benh nhan an chao, che do an LAT va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_chao_lat_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_LAT_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 1 -- -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD, STM,CM
	)
GROUP BY v_bnga.`NGAYAN`;

-- ##########################################################

-- View : v_count_chao_thg_6h : Count so benh nhan an chao, che do an THUONG (khong co che do DD, STM,CM, LAT) vao luc 6h
CREATE OR REPLACE VIEW  v_count_chao_thg_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_THG_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM,CM,LAT
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_thg_6h : Count so benh nhan an chao, che do an THUONG va co an 1 trong cac che do an khac (khong co che do DD,STM,CM,LAT), vao luc 6h
CREATE OR REPLACE VIEW  v_has_chao_thg_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_THG_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM, CM, LAT
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_chao_thg_11h : Count so benh nhan an chao, che do an THUONG vao luc 11h
CREATE OR REPLACE VIEW  v_count_chao_thg_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_THG_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM,CM, LAT
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_thg_11h : Count so benh nhan an chao, che do an THUONG va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_chao_thg_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_THG_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD, STM ,CM, LAT
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_chao_thg_16h : Count so benh nhan an chao, che do an THUONG vao luc 16h
CREATE OR REPLACE VIEW  v_count_chao_thg_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_THG_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM,CM,LAT
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_thg_16h : Count so benh nhan an chao, che do an THUONG va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_chao_thg_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_THG_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 4  -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD, STM, CM, LAT
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_chao_thg_20h : Count so benh nhan an chao, che do an THUONG vao luc 20h
CREATE OR REPLACE VIEW  v_count_chao_thg_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_CHAO_THG_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
	AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM,CM,LAT
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_chao_thg_20h : Count so benh nhan an chao, che do an THUONG va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_chao_thg_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_CHAO_THG_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 2 -- DTDMLA2_MASO = 2 (loai an chao)
    )
	  AND bncda.`DTDMCDA_MASO` = 4 -- -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD, STM,CM
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_com_dd_6h : Count so benh nhan an com, che do an DD vao luc 6h
CREATE OR REPLACE VIEW  v_count_com_dd_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_DD_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 2 -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_dd_6h : Count so benh nhan an com, che do an DD va co an 1 trong cac che do an khac, vao luc 6h
CREATE OR REPLACE VIEW  v_has_com_dd_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_DD_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 2 -- -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_com_dd_11h : Count so benh nhan an com, che do an DD vao luc 11h
CREATE OR REPLACE VIEW  v_count_com_dd_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_DD_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 2 -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_dd_11h : Count so benh nhan an com, che do an DD va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_com_dd_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_DD_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an qua com)
    )
	  AND bncda.`DTDMCDA_MASO` = 2 -- -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_com_dd_16h : Count so benh nhan an com, che do an DD vao luc 16h
CREATE OR REPLACE VIEW  v_count_com_dd_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_DD_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an qua com)
	AND bncda.`DTDMCDA_MASO` = 2 -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_dd_16h : Count so benh nhan an com, che do an DD va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_com_dd_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_DD_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 2 -- -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_com_dd_20h : Count so benh nhan an com, che do an DD vao luc 20h
CREATE OR REPLACE VIEW  v_count_com_dd_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_DD_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an qua com)
	AND bncda.`DTDMCDA_MASO` = 2 -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_dd_20h : Count so benh nhan an com, che do an DD va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_com_dd_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_DD_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an qua com)
    )
	  AND bncda.`DTDMCDA_MASO` = 2 -- -- DTDMCDA_MASO = 2  (la che do an DD)
GROUP BY v_bnga.`NGAYAN`;
-- ##########################################################

-- View : v_count_com_stm_6h : Count so benh nhan an com, che do an STM (khong co che do DD) vao luc 6h
CREATE OR REPLACE VIEW  v_count_com_stm_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_STM_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 3 -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_stm_6h : Count so benh nhan an com, che do an STM va co an 1 trong cac che do an khac (khong co che do DD), vao luc 6h
CREATE OR REPLACE VIEW  v_has_com_stm_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_STM_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 3 -- -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_com_stm_11h : Count so benh nhan an com, che do an STM vao luc 11h
CREATE OR REPLACE VIEW  v_count_com_stm_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_STM_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 3 -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_stm_11h : Count so benh nhan an com, che do an STM va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_com_stm_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_STM_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 3 -- -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_com_stm_16h : Count so benh nhan an com, che do an STM vao luc 16h
CREATE OR REPLACE VIEW  v_count_com_stm_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_STM_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 3 -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_stm_16h : Count so benh nhan an com, che do an STM va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_com_stm_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_STM_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 3 -- -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_com_stm_20h : Count so benh nhan an com, che do an STM vao luc 20h
CREATE OR REPLACE VIEW  v_count_com_stm_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_STM_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 3 -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_stm_20h : Count so benh nhan an com, che do an STM va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_com_stm_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_STM_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 3 -- -- DTDMCDA_MASO = 3  (la che do an STM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` = 2  -- Khong co che do an DD
	)
GROUP BY v_bnga.`NGAYAN`;

-- ##########################################################

-- View : v_count_com_cm_6h : Count so benh nhan an com, che do an CM (khong co che do DD, STM) vao luc 6h
CREATE OR REPLACE VIEW  v_count_com_cm_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_CM_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 5 -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_cm_6h : Count so benh nhan an com, che do an CM va co an 1 trong cac che do an khac (khong co che do DD,STM), vao luc 6h
CREATE OR REPLACE VIEW  v_has_com_cm_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_CM_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an qua com)
    )
	  AND bncda.`DTDMCDA_MASO` = 5 -- -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_com_cm_11h : Count so benh nhan an com, che do an CM vao luc 11h
CREATE OR REPLACE VIEW  v_count_com_cm_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_CM_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 5 -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_cm_11h : Count so benh nhan an com, che do an CM va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_com_cm_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_CM_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 5 -- -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD, STM
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_com_cm_16h : Count so benh nhan an com, che do an CM vao luc 16h
CREATE OR REPLACE VIEW  v_count_com_cm_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_CM_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 5 -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_cm_16h : Count so benh nhan an com, che do an CM va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_com_cm_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_CM_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 5 -- -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD, STM
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_com_cm_20h : Count so benh nhan an com, che do an CM vao luc 20h
CREATE OR REPLACE VIEW  v_count_com_cm_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_CM_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 5 -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD,STM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_cm_20h : Count so benh nhan an com, che do an CM va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_com_cm_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_CM_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 5 -- -- DTDMCDA_MASO = 5  (la che do an CM)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3)  -- Khong co che do an DD, STM
	)
GROUP BY v_bnga.`NGAYAN`;

-- ##########################################################

-- View : v_count_com_lat_6h : Count so benh nhan an com, che do an LAT (khong co che do DD, STM,CM) vao luc 6h
CREATE OR REPLACE VIEW  v_count_com_lat_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_LAT_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM,CM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_lat_6h : Count so benh nhan an com, che do an LAT va co an 1 trong cac che do an khac (khong co che do DD,STM,CM), vao luc 6h
CREATE OR REPLACE VIEW  v_has_com_lat_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_LAT_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 1 -- -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM, CM
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_com_lat_11h : Count so benh nhan an com, che do an LAT vao luc 11h
CREATE OR REPLACE VIEW  v_count_com_lat_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_LAT_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM,CM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_lat_11h : Count so benh nhan an com, che do an LAT va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_com_lat_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_LAT_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD, STM ,CM
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_com_lat_16h : Count so benh nhan an com, che do an LAT vao luc 16h
CREATE OR REPLACE VIEW  v_count_com_lat_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_LAT_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM,CM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_lat_16h : Count so benh nhan an com, che do an LAT va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_com_lat_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_LAT_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 1  -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD, STM, CM
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_com_lat_20h : Count so benh nhan an com, che do an LAT vao luc 20h
CREATE OR REPLACE VIEW  v_count_com_lat_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_LAT_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 1 -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD,STM,CM
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_lat_20h : Count so benh nhan an com, che do an LAT va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_com_lat_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_LAT_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 1 -- -- DTDMCDA_MASO = 1  (la che do an LAT)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5)  -- Khong co che do an DD, STM,CM
	)
GROUP BY v_bnga.`NGAYAN`;

-- ##########################################################

-- View : v_count_com_thg_6h : Count so benh nhan an com, che do an THUONG (khong co che do DD, STM,CM, LAT) vao luc 6h
CREATE OR REPLACE VIEW  v_count_com_thg_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_THG_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM,CM,LAT
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_thg_6h : Count so benh nhan an com, che do an THUONG va co an 1 trong cac che do an khac (khong co che do DD,STM,CM,LAT), vao luc 6h
CREATE OR REPLACE VIEW  v_has_com_thg_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_THG_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM, CM, LAT
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_com_thg_11h : Count so benh nhan an com, che do an THUONG vao luc 11h
CREATE OR REPLACE VIEW  v_count_com_thg_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_THG_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM,CM, LAT
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_thg_11h : Count so benh nhan an com, che do an THUONG va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_com_thg_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_THG_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD, STM ,CM, LAT
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_com_thg_16h : Count so benh nhan an com, che do an THUONG vao luc 16h
CREATE OR REPLACE VIEW  v_count_com_thg_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_THG_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM,CM,LAT
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_thg_16h : Count so benh nhan an com, che do an THUONG va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_com_thg_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_THG_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 4  -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD, STM, CM, LAT
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_com_thg_20h : Count so benh nhan an com, che do an THUONG vao luc 20h
CREATE OR REPLACE VIEW  v_count_com_thg_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_THG_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 4 -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD,STM,CM,LAT
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_thg_20h : Count so benh nhan an com, che do an THUONG va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_com_thg_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_THG_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 4 -- -- DTDMCDA_MASO = 4  (la che do an THUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1)  -- Khong co che do an DD, STM,CM
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_com_bdng_6h : Count so benh nhan an com, che do an BOI DUONG (khong co che do DD, STM,CM, LAT, THUONG) vao luc 6h
CREATE OR REPLACE VIEW  v_count_com_bdng_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_BDUONG_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 6 -- DTDMCDA_MASO = 6  (la che do an BDUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1,4)  -- Khong co che do an DD,STM,CM,LAT,THUONG
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_bdng_6h : Count so benh nhan an com, che do an BOI DUONG va co an 1 trong cac che do an khac (khong co che do DD,STM,CM,LAT, THUONG), vao luc 6h
CREATE OR REPLACE VIEW  v_has_com_bdng_6h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_BDUONG_6H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 1  -- DTDMGA_MASO = 1 (la an luc 6h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 6 -- DTDMCDA_MASO = 6  (la che do an BDUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1,4)  -- Khong co che do an DD,STM, CM, LAT, THUONG
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_com_bdng_11h : Count so benh nhan an com, che do an BDUONG vao luc 11h
CREATE OR REPLACE VIEW  v_count_com_bdng_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_BDUONG_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 6 -- DTDMCDA_MASO = 6  (la che do an BDUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1,4)  -- Khong co che do an DD,STM,CM, LAT, THUONG
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_bdng_11h : Count so benh nhan an com, che do an BDUONG va co an 1 trong cac che do an khac, vao luc 11h
CREATE OR REPLACE VIEW  v_has_com_bdng_11h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_BDUONG_11H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 2  -- DTDMGA_MASO = 2 (la an luc 11h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 6 -- DTDMCDA_MASO = 6  (la che do an BDUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1,4)  -- Khong co che do an DD, STM ,CM, LAT, THUONG
	)
GROUP BY v_bnga.`NGAYAN`;
-- View : v_count_com_bdng_16h : Count so benh nhan an com, che do an BDUONG vao luc 16h
CREATE OR REPLACE VIEW  v_count_com_bdng_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_BDUONG_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 6 -- DTDMCDA_MASO = 6  (la che do an BDUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1,4)  -- Khong co che do an DD,STM,CM,LAT,THUONG
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_bdng_16h : Count so benh nhan an com, che do an BDUONG va co an 1 trong cac che do an khac, vao luc 16h
CREATE OR REPLACE VIEW  v_has_com_bdng_16h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_BDUONG_16H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 3  -- DTDMGA_MASO = 3 (la an luc 16h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 6  -- DTDMCDA_MASO = 6  (la che do an BDUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1,4)  -- Khong co che do an DD, STM, CM, LAT, THUONG
	)
GROUP BY v_bnga.`NGAYAN`;

-- View : v_count_com_bdng_20h : Count so benh nhan an com, che do an BDUONG vao luc 20h
CREATE OR REPLACE VIEW  v_count_com_bdng_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`DTDMGA_MASO`) AS COUNT_COM_BDUONG_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`DTDMGA_MASO` = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
  AND v_bnga.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
	AND bncda.`DTDMCDA_MASO` = 6 -- DTDMCDA_MASO = 6  (la che do an BDUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1,4)  -- Khong co che do an DD,STM,CM,LAT,THUONG
  )
GROUP BY v_bnga.`NGAYAN`;

-- View : v_has_com_bdng_20h : Count so benh nhan an com, che do an BDUONG va co an 1 trong cac che do an khac, vao luc 20h
CREATE OR REPLACE VIEW  v_has_com_bdng_20h
AS
Select v_bnga.`NGAYAN` AS NGAYAN,
       Count(v_bnga.`BNPBA_MASO`) AS HAS_COM_BDUONG_20H
FROM v_benh_nhan_gio_an v_bnga LEFT JOIN benh_nhan_che_do_an bncda ON v_bnga.`BNPBA_MASO` = bncda.`BNPBA_MASO`
WHERE v_bnga.`BNPBA_MASO` IN (
    Select v_bnga1.`BNPBA_MASO`
    From v_benh_nhan_gio_an v_bnga1
    WHERE v_bnga1.`DTDMGA_MASO`  = 4  -- DTDMGA_MASO = 4 (la an luc 20h)
    AND v_bnga1.`DTDMLA2_MASO` = 3 -- DTDMLA2_MASO = 3 (loai an com)
    )
	  AND bncda.`DTDMCDA_MASO` = 6 -- -- DTDMCDA_MASO = 6  (la che do an BDUONG)
	AND v_bnga.`BNPBA_MASO` NOT IN (
    Select bncda1.`BNPBA_MASO` FROM benh_nhan_che_do_an bncda1
    WHERE bncda1.`DTDMCDA_MASO` IN (2,3,5,1,4)  -- Khong co che do an DD, STM,CM, THUONG
	)
GROUP BY v_bnga.`NGAYAN`;