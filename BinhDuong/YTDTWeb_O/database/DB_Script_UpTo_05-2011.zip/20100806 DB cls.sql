USE db_ytdt_bd;

alter table `db_ytdt_bd`.`cls_kham` 
   add column `CLSKHAM_DULIEUHINHANH` varchar(512) NULL after `CLSKHAM_NOIDUNGTHU`