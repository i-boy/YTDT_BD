﻿CREATE TABLE  `db_ytdt_bd`.`dt_dm_buong` (
  `DTDMB_MASO` int(10) unsigned NOT NULL auto_increment,
  `DTDMB_MA` varchar(50) collate utf8_unicode_ci NOT NULL,
  `DTDMB_TEN` varchar(100) collate utf8_unicode_ci default NULL,
  `DTDMB_NGAYGIOCN` double default NULL,
  `DTDMB_CHON` tinyint(1) unsigned default '1',
  `DMKHOA_MASO` int(10) unsigned default NULL,
  PRIMARY KEY  (`DTDMB_MASO`),
  UNIQUE KEY `DTDMB_MA` (`DTDMB_MA`),
  KEY `FK_dt_dm_buong` (`DMKHOA_MASO`),
  CONSTRAINT `FK_dt_dm_buong` FOREIGN KEY (`DMKHOA_MASO`) REFERENCES `dm_khoa` (`DMKHOA_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC COMMENT=' Luu danh muc buong theo khoa, phuc vu  lap bc nuoc';


CREATE TABLE  `db_ytdt_bd`.`nhap_nuoc` (
  `NHAPNUOC_MASO` int(10) unsigned NOT NULL auto_increment,
  `NHAPNUOC_NGAY` date default NULL,
  `NHAPNUOC_SOLUONG` int(10) unsigned default NULL,
  `DTDMB_MASO` int(10) unsigned default NULL,
  `DMKHOA_MASO` int(10) unsigned default NULL,
  PRIMARY KEY  (`NHAPNUOC_MASO`),
  KEY `FK_nhap_nuoc_1` (`DTDMB_MASO`),
  KEY `FK_nhap_nuoc_2` (`DMKHOA_MASO`),
  CONSTRAINT `FK_nhap_nuoc_1` FOREIGN KEY (`DTDMB_MASO`) REFERENCES `dt_dm_buong` (`DTDMB_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_nhap_nuoc_2` FOREIGN KEY (`DMKHOA_MASO`) REFERENCES `dm_khoa` (`DMKHOA_MASO`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Phuc vu bao cao nuoc (phan he dinh duong)';