-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.67-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema db_ytdt_bd
--

CREATE DATABASE IF NOT EXISTS db_ytdt_bd;
USE db_ytdt_bd;

--
-- Definition of table `hsba_chi_tiet_rhm`
--

DROP TABLE IF EXISTS `hsba_chi_tiet_rhm`;
CREATE TABLE `hsba_chi_tiet_rhm` (
  `HSBACTRHM_MA` int(11) NOT NULL auto_increment,
  `HSBACM_MA` int(11) NOT NULL,
  `HSBACTRHM_QTBENHLY` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_TIENSUBENHBT` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_TIENSUBENHGD` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_DD_DIUNG` tinyint(1) default NULL,
  `HSBACTRHM_DD_MATUY` tinyint(1) default NULL,
  `HSBACTRHM_DD_RUOUBIA` tinyint(1) default NULL,
  `HSBACTRHM_DD_THUOCLA` tinyint(1) default NULL,
  `HSBACTRHM_DD_THUOCLAO` tinyint(1) default NULL,
  `HSBACTRHM_DD_KHAC` tinyint(1) default NULL,
  `HSBACTRHM_DD_DIUNG_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_DD_MATUY_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_DD_RUOUBIA_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_DD_THUOCLA_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_DD_THUOCLAO_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_DD_KHAC_TG` varchar(32) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_TUANHOAN` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_HOHAP` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_TIEUHOA` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_THANTIETNIEUSINHHOC` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_THANKINH` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_COXUONGKHOP` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_TMH` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_MAT` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_NT_DD_BLK` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_TTBA` varchar(512) character set utf8 collate utf8_unicode_ci default NULL,
  `HSBACTRHM_PB` int(10) unsigned default NULL,
  `HSBACTRHM_TIENLUONG` int(10) unsigned default NULL,
  `HSBACTRHM_LYDOVAOV` varchar(512) default NULL,
  `HSBACTRHM_NGAYBENHTHU` int(10) unsigned default NULL,
  `HSBACTRHM_TOANTHAN` varchar(512) default NULL,
  `HSBACTRHM_QTBL_DBLS` varchar(512) default NULL,
  `HSBACTRHM_TTKQXNCLS` varchar(512) default NULL,
  `HSBACTRHM_PPDIEUTRI` varchar(512) default NULL,
  `HSBACTRHM_TTNGUOIBENHRAV` varchar(512) default NULL,
  `HSBACTRHM_HUONGDT_CDTT` varchar(512) default NULL,
  `HSBACTRHM_SOTOXQUANG` int(10) unsigned default NULL,
  `HSBACTRHM_SOTOCTSCANNER` int(10) unsigned default NULL,
  `HSBACTRHM_SOTOSIEUAM` int(10) unsigned default NULL,
  `HSBACTRHM_SOTOXN` int(10) unsigned default NULL,
  `HSBACTRHM_SOTOKHAC` int(10) unsigned default NULL,
  `HSBACTRHM_SOTOLOAIKHAC` varchar(512) default NULL,
  `HSBACTRHM_TONGSOTO` int(10) unsigned default NULL,
  `HSBACTRHM_BSLAMBA` int(10) unsigned default NULL,
  `HSBACTRHM_NGUOIGIAOBA` int(10) unsigned default NULL,
  `HSBACTRHM_NGUOINHANBA` int(10) unsigned default NULL,
  `HSBACTRHM_BSDIEUTRI` int(10) unsigned default NULL,
  `CHITIETCOQUANBENH` varchar(500) default NULL,
  `HSBACTRHM_COQUANKHAC` varchar(20) default NULL,
  `HSBACTRHM_CHITIETBENHCOQUANKHAC` varchar(500) default NULL,
  `HUYETHOC_MA` varchar(1) default NULL,
  `HUYETHOC_KQ` varchar(200) default NULL,
  `HOASINH_MA` varchar(1) default NULL,
  `HOASINH_KQ` varchar(200) default NULL,
  `VISINH_MA` varchar(1) default NULL,
  `VISINH_KQ` varchar(200) default NULL,
  `XQUANG_MA` varchar(1) default NULL,
  `XQUANG_KQ` varchar(200) default NULL,
  `SIEUAM_MA` varchar(1) default NULL,
  `SIEUAM_KQ` varchar(200) default NULL,
  `NOISOI_MA` varchar(1) default NULL,
  `NOISOI_KQ` varchar(200) default NULL,
  `GPB_MA` varchar(1) default NULL,
  `GPB_KQ` varchar(200) default NULL,
  `XETNGHIEMKHAC_MA` varchar(1) default NULL,
  `XETNGHIEMKHAC_KQ` varchar(200) default NULL,
  `XETNGHIEM_TOMTAT` varchar(500) default NULL,
  `CHDANUONGBENHLY` varchar(20) default NULL,
  `CHDOCHAMSOC` varchar(1) default NULL,
  `GIAIPHAUBENHCHITIET` varchar(100) default NULL,
  PRIMARY KEY  (`HSBACTRHM_MA`),
  KEY `FK_hsba_chi_tiet_rhm_1` (`HSBACM_MA`),
  KEY `FK_hsba_chi_tiet_rhm_2` (`HSBACTRHM_BSLAMBA`),
  KEY `FK_hsba_chi_tiet_rhm_3` (`HSBACTRHM_NGUOIGIAOBA`),
  KEY `FK_hsba_chi_tiet_rhm_4` (`HSBACTRHM_NGUOINHANBA`),
  KEY `FK_hsba_chi_tiet_rhm_5` (`HSBACTRHM_BSDIEUTRI`),
  KEY `FK_hsba_chi_tiet_rhm_6` (`HSBACTRHM_TIENLUONG`),
  CONSTRAINT `FK_hsba_chi_tiet_rhm_1` FOREIGN KEY (`HSBACM_MA`) REFERENCES `hsba_chuyen_mon` (`HSBACM_MA`),
  CONSTRAINT `FK_hsba_chi_tiet_rhm_2` FOREIGN KEY (`HSBACTRHM_BSLAMBA`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`),
  CONSTRAINT `FK_hsba_chi_tiet_rhm_3` FOREIGN KEY (`HSBACTRHM_NGUOIGIAOBA`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`),
  CONSTRAINT `FK_hsba_chi_tiet_rhm_4` FOREIGN KEY (`HSBACTRHM_NGUOINHANBA`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`),
  CONSTRAINT `FK_hsba_chi_tiet_rhm_5` FOREIGN KEY (`HSBACTRHM_BSDIEUTRI`) REFERENCES `dt_dm_nhan_vien` (`DTDMNHANVIEN_MASO`),
  CONSTRAINT `FK_hsba_chi_tiet_rhm_6` FOREIGN KEY (`HSBACTRHM_TIENLUONG`) REFERENCES `dm_thuoc` (`DMTHUOC_MASO`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
